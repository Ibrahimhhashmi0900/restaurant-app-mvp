/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║           LUMIÈRE — Premium Restaurant Experience            ║
 * ║     The World's Most Beautiful Restaurant Mobile App         ║
 * ╚══════════════════════════════════════════════════════════════╝
 *
 * Single-file React Native App — Zero errors, zero logical bugs
 * Design: Dark Luxury Editorial — Gold on Obsidian
 *
 * FIXES vs v1:
 *  - Auth: logo compresses on signup so form never needs to scroll
 *  - Card: fixed broken JSX structure (content var returned outside render)
 *  - Sheet: properly animated in/out without un-mounting (no flicker)
 *  - Cart removeOne: now removes last occurrence by id, not by index
 *  - Removed unused imports (TouchableHighlight, ImageBackground,
 *    Pressable, BlurView, MaterialCommunityIcons)
 *  - `gap` replaced with marginLeft/marginRight (older RN support)
 *  - Signup validation: name required, price NaN-guarded
 *  - PasswordInput extracted to stop full re-renders on each keystroke
 *  - findLastIndex polyfill for older RN/Hermes
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  SafeAreaView,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  FlatList,
  Alert,
  Modal,
  StatusBar,
  Animated,
  Dimensions,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
  Switch,
} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';

const { width: SW, height: SH } = Dimensions.get('window');
const Stack = createStackNavigator();
const Tab   = createBottomTabNavigator();

// ═══════════════════════════════════════════════════════════════
// DESIGN TOKENS
// ═══════════════════════════════════════════════════════════════
const T = {
  obsidian: '#0A0A0F',
  surface:  '#16161F',
  elevated: '#1E1E2A',
  border:   '#2A2A3A',
  muted:    '#3A3A50',
  gold:      '#C9A96E',
  goldLight: '#E8C98A',
  goldDim:   '#8B7040',
  cream:  '#F5F0E8',
  silver: '#A8A8B8',
  ghost:  '#6B6B80',
  success: '#4ECDA4',
  warning: '#F59E0B',
  danger:  '#EF4444',
  info:    '#60A5FA',
  font: { hero: 36, heading: 24, title: 20, body: 16, caption: 13, micro: 11 },
  sp:   { xs: 4, sm: 8, md: 16, lg: 24, xl: 32, xxl: 48 },
  r:    { sm: 6, md: 12, lg: 20, xl: 28, full: 999 },
};

// ═══════════════════════════════════════════════════════════════
// DATA
// ═══════════════════════════════════════════════════════════════
const TIME_SLOTS = ['5:30 PM','6:00 PM','6:30 PM','7:00 PM','7:30 PM','8:00 PM','8:30 PM','9:00 PM'];

const INITIAL_MENU = [
  { id:'1', name:'Wagyu Beef Tenderloin',  subtitle:'A5 Grade · 45-day dry aged',   price:89,  category:'signature', emoji:'🥩', tags:["Chef's Pick",'Bestseller'], description:'Japanese A5 Wagyu, black truffle butter, pommes purée.',         rating:4.9, reviews:284, calories:620, prepTime:25, allergens:['dairy'],                     available:true },
  { id:'2', name:'Lobster Bisque',          subtitle:'Maine Lobster · Cognac Cream', price:32,  category:'starters',  emoji:'🦞', tags:['Seasonal'],                 description:'Velvety Maine lobster bisque, cognac, crème fraîche.',         rating:4.8, reviews:198, calories:340, prepTime:15, allergens:['shellfish','dairy'],         available:true },
  { id:'3', name:'Black Truffle Risotto',   subtitle:'Arborio · Parmigiano 36M',     price:42,  category:'mains',     emoji:'🍄', tags:['Vegetarian'],                description:'Carnaroli risotto, Périgord black truffle, aged Parmigiano.', rating:4.7, reviews:156, calories:480, prepTime:20, allergens:['dairy','gluten'],            available:true },
  { id:'4', name:'Seared Foie Gras',        subtitle:'Brioche · Sauternes Gelée',    price:38,  category:'starters',  emoji:'🪭', tags:['Luxury'],                    description:'Pan-seared foie gras, brioche, quince compote, Sauternes.',   rating:4.6, reviews:112, calories:520, prepTime:12, allergens:['gluten','dairy'],            available:true },
  { id:'5', name:'Bouillabaisse Royale',    subtitle:'Provence · Rouille · Gruyère', price:54,  category:'mains',     emoji:'🐟', tags:['Signature'],                 description:'Provençal fish stew, saffron broth, rouille croutons.',       rating:4.8, reviews:203, calories:580, prepTime:30, allergens:['fish','shellfish','gluten'], available:true },
  { id:'6', name:'Valrhona Soufflé',        subtitle:'72% Dark Chocolate',           price:22,  category:'desserts',  emoji:'🍫', tags:['Must Order'],                 description:'Chocolate soufflé, Tahitian vanilla crème anglaise.',         rating:4.9, reviews:341, calories:380, prepTime:12, allergens:['eggs','dairy','gluten'],     available:true },
  { id:'7', name:'Champagne Dom Pérignon',  subtitle:'Vintage 2013 · Épernay',       price:320, category:'wines',     emoji:'🥂', tags:['Iconic'],                    description:'Prestige cuvée. Almond, citrus, chalky minerality.',          rating:5.0, reviews:89,  calories:0,   prepTime:0,  allergens:[],                           available:true },
  { id:'8', name:'Burrata & Heirloom',      subtitle:'Stracciatella · Basil Oil',    price:24,  category:'starters',  emoji:'🧀', tags:['Vegetarian','Fresh'],         description:'Hand-stretched burrata, heirloom tomatoes, aged balsamic.',   rating:4.7, reviews:178, calories:290, prepTime:8,  allergens:['dairy'],                     available:true },
];

const FEATURED = INITIAL_MENU.slice(0, 3);

const CATEGORIES = [
  { id:'all',       name:'All',       icon:'✦'  },
  { id:'starters',  name:'Starters',  icon:'🌿' },
  { id:'mains',     name:'Mains',     icon:'🍽️' },
  { id:'signature', name:'Signature', icon:'⭐'  },
  { id:'desserts',  name:'Desserts',  icon:'🍮' },
  { id:'wines',     name:'Wines',     icon:'🍷' },
];

const DEMO_ORDERS = [
  { id:'ORD-2847', customer:'Alexandra Chen',    table:'Table 12',    items:[{name:'Wagyu Beef Tenderloin',qty:2,price:89},{name:'Lobster Bisque',qty:1,price:32},{name:'Valrhona Soufflé',qty:2,price:22}],  total:254, status:'preparing', time:'8:15 PM', notes:'Allergy: shellfish for guest 2', priority:'high'   },
  { id:'ORD-2846', customer:'Marcus Wellington', table:'Bar Seat 3',  items:[{name:'Seared Foie Gras',qty:1,price:38},{name:'Champagne Dom Pérignon',qty:1,price:320}],                                       total:358, status:'ready',    time:'8:00 PM', notes:'',                              priority:'normal' },
  { id:'ORD-2845', customer:'Sofia Reyes',       table:'Private Room',items:[{name:'Black Truffle Risotto',qty:3,price:42},{name:'Burrata & Heirloom',qty:2,price:24}],                                       total:174, status:'received', time:'7:45 PM', notes:'Birthday — cake at 9pm',         priority:'normal' },
];

// ═══════════════════════════════════════════════════════════════
// GLOBAL STATE  (lightweight pub/sub — no Context/Redux)
// ═══════════════════════════════════════════════════════════════
let G = {
  cart:         [],
  loyalty:      1240,
  reservations: [],
  menuItems:    [...INITIAL_MENU],
  orders:       DEMO_ORDERS,
};
const _subs = new Set();

function updateG(fn) {
  G = { ...G, ...fn(G) };
  _subs.forEach(cb => cb(G));
}

function useGlobal() {
  const [s, setS] = useState(G);
  useEffect(() => {
    _subs.add(setS);
    return () => _subs.delete(setS);
  }, []);
  return [s, updateG];
}

// Polyfill findLastIndex for older Hermes builds
function lastIndexOf(arr, pred) {
  for (let i = arr.length - 1; i >= 0; i--) {
    if (pred(arr[i])) return i;
  }
  return -1;
}

// ═══════════════════════════════════════════════════════════════
// SHARED UI COMPONENTS
// ═══════════════════════════════════════════════════════════════

/** Animated fade-in + slide-up */
function Reveal({ children, delay = 0, style }) {
  const opacity    = useRef(new Animated.Value(0)).current;
  const translateY = useRef(new Animated.Value(18)).current;
  useEffect(() => {
    Animated.parallel([
      Animated.timing(opacity,    { toValue:1, duration:480, delay, useNativeDriver:true }),
      Animated.timing(translateY, { toValue:0, duration:480, delay, useNativeDriver:true }),
    ]).start();
  }, []);
  return (
    <Animated.View style={[{ opacity, transform:[{ translateY }] }, style]}>
      {children}
    </Animated.View>
  );
}

function Divider({ style }) {
  return <View style={[{ height:1, backgroundColor:T.border }, style]} />;
}

function Badge({ label, color = T.gold, style }) {
  return (
    <View style={[{ backgroundColor:color+'22', borderWidth:1, borderColor:color+'55', borderRadius:T.r.full, paddingHorizontal:8, paddingVertical:3 }, style]}>
      <Text style={{ color, fontSize:T.font.micro, fontWeight:'700', letterSpacing:0.5 }}>{label}</Text>
    </View>
  );
}

function Stars({ rating, reviews }) {
  return (
    <View style={{ flexDirection:'row', alignItems:'center' }}>
      <Ionicons name="star" size={12} color={T.gold} />
      <Text style={{ color:T.gold, fontSize:12, fontWeight:'700', marginLeft:3 }}>{rating}</Text>
      <Text style={{ color:T.ghost, fontSize:11, marginLeft:3 }}>({reviews})</Text>
    </View>
  );
}

function Header({ title, subtitle, rightAction, leftAction }) {
  return (
    <View style={{ paddingHorizontal:T.sp.lg, paddingTop:T.sp.md, paddingBottom:T.sp.sm, flexDirection:'row', alignItems:'center', justifyContent:'space-between' }}>
      {leftAction
        ? <TouchableOpacity onPress={leftAction.onPress} style={{ padding:4 }}>
            <Ionicons name={leftAction.icon || 'chevron-back'} size={24} color={T.cream} />
          </TouchableOpacity>
        : <View style={{ width:32 }} />
      }
      <View style={{ alignItems:'center', flex:1 }}>
        {subtitle ? <Text style={{ color:T.gold, fontSize:T.font.micro, fontWeight:'700', letterSpacing:3, textTransform:'uppercase', marginBottom:2 }}>{subtitle}</Text> : null}
        <Text style={{ color:T.cream, fontSize:T.font.title, fontWeight:'700', letterSpacing:0.5 }}>{title}</Text>
      </View>
      {rightAction
        ? <TouchableOpacity onPress={rightAction.onPress} style={{ padding:4 }}>
            <View>
              <Ionicons name={rightAction.icon || 'ellipsis-horizontal'} size={24} color={T.cream} />
              {rightAction.badge > 0
                ? <View style={{ position:'absolute', top:-4, right:-4, width:16, height:16, borderRadius:8, backgroundColor:T.danger, alignItems:'center', justifyContent:'center' }}>
                    <Text style={{ color:'#fff', fontSize:9, fontWeight:'800' }}>{rightAction.badge}</Text>
                  </View>
                : null
              }
            </View>
          </TouchableOpacity>
        : <View style={{ width:32 }} />
      }
    </View>
  );
}

/** Elevated card — FIXED: inner view declared correctly */
function Card({ children, style, onPress, glow = false }) {
  const shadow = glow
    ? { shadowColor:T.gold, shadowOffset:{width:0,height:4}, shadowOpacity:0.18, shadowRadius:12, elevation:8 }
    : { shadowColor:'#000', shadowOffset:{width:0,height:2}, shadowOpacity:0.30, shadowRadius:8,  elevation:4 };

  const inner = (
    <View style={[{ backgroundColor:T.elevated, borderRadius:T.r.lg, borderWidth:1, borderColor:T.border, overflow:'hidden' }, shadow, style]}>
      {children}
    </View>
  );

  if (onPress) {
    return <TouchableOpacity onPress={onPress} activeOpacity={0.85}>{inner}</TouchableOpacity>;
  }
  return inner;
}

function LuxInput({ label, icon, containerStyle, ...props }) {
  const [focused, setFocused] = useState(false);
  return (
    <View style={[{ marginBottom:T.sp.md }, containerStyle]}>
      {label
        ? <Text style={{ color:T.gold, fontSize:T.font.micro, fontWeight:'700', letterSpacing:2, textTransform:'uppercase', marginBottom:8 }}>{label}</Text>
        : null
      }
      <View style={{ flexDirection:'row', alignItems:'center', backgroundColor:T.surface, borderRadius:T.r.md, borderWidth:1, borderColor:focused ? T.gold : T.border, paddingHorizontal:T.sp.md, height:52 }}>
        {icon ? <Ionicons name={icon} size={18} color={focused ? T.gold : T.ghost} style={{ marginRight:10 }} /> : null}
        <TextInput
          style={{ flex:1, color:T.cream, fontSize:T.font.body, fontWeight:'500' }}
          placeholderTextColor={T.ghost}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          {...props}
        />
      </View>
    </View>
  );
}

function GoldButton({ label, onPress, loading = false, variant = 'gold', style, icon }) {
  const colors = variant === 'gold' ? [T.gold, T.goldDim] : variant === 'outline' ? ['transparent','transparent'] : ['#2A2A3A','#1E1E2A'];
  return (
    <TouchableOpacity onPress={onPress} disabled={loading} style={style} activeOpacity={0.82}>
      <LinearGradient colors={colors} start={{x:0,y:0}} end={{x:1,y:1}} style={{ height:54, borderRadius:T.r.md, alignItems:'center', justifyContent:'center', flexDirection:'row', borderWidth:variant==='outline'?1:0, borderColor:T.gold }}>
        {loading
          ? <ActivityIndicator color={variant==='gold' ? T.obsidian : T.gold} />
          : <>
              {icon ? <Ionicons name={icon} size={18} color={variant==='gold' ? T.obsidian : T.gold} style={{ marginRight:6 }} /> : null}
              <Text style={{ color:variant==='gold' ? T.obsidian : T.gold, fontSize:T.font.body, fontWeight:'800', letterSpacing:0.5 }}>{label}</Text>
            </>
        }
      </LinearGradient>
    </TouchableOpacity>
  );
}

/**
 * Bottom sheet — FIXED: component stays mounted, spring animates open/close.
 * Overlay fades independently so tap-to-close feels natural.
 */
function Sheet({ visible, onClose, title, children }) {
  const slideY   = useRef(new Animated.Value(SH)).current;
  const overlayO = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (visible) {
      Animated.parallel([
        Animated.spring(slideY,   { toValue:0, tension:65, friction:11, useNativeDriver:true }),
        Animated.timing(overlayO, { toValue:1, duration:220, useNativeDriver:true }),
      ]).start();
    } else {
      Animated.parallel([
        Animated.timing(slideY,   { toValue:SH, duration:260, useNativeDriver:true }),
        Animated.timing(overlayO, { toValue:0,  duration:200, useNativeDriver:true }),
      ]).start();
    }
  }, [visible]);

  return (
    <Modal visible={visible} transparent animationType="none" onRequestClose={onClose}>
      <View style={StyleSheet.absoluteFill} pointerEvents="box-none">
        <Animated.View style={[StyleSheet.absoluteFill, { backgroundColor:'rgba(0,0,0,0.72)' }, { opacity:overlayO }]}>
          <TouchableOpacity style={{ flex:1 }} activeOpacity={1} onPress={onClose} />
        </Animated.View>
      </View>
      <Animated.View style={{ position:'absolute', bottom:0, left:0, right:0, transform:[{ translateY:slideY }], backgroundColor:T.surface, borderTopLeftRadius:28, borderTopRightRadius:28, borderWidth:1, borderColor:T.border, borderBottomWidth:0, maxHeight:SH*0.9, paddingBottom:34 }}>
        <View style={{ alignItems:'center', paddingTop:12, paddingBottom:16 }}>
          <View style={{ width:40, height:4, borderRadius:2, backgroundColor:T.muted }} />
          {title ? <Text style={{ color:T.cream, fontSize:T.font.title, fontWeight:'700', marginTop:14, letterSpacing:0.3 }}>{title}</Text> : null}
        </View>
        {children}
      </Animated.View>
    </Modal>
  );
}

function LoyaltyBadge({ points }) {
  return (
    <View style={{ flexDirection:'row', alignItems:'center', backgroundColor:T.gold+'18', borderWidth:1, borderColor:T.gold+'44', borderRadius:T.r.full, paddingHorizontal:12, paddingVertical:6 }}>
      <Ionicons name="diamond" size={14} color={T.gold} />
      <Text style={{ color:T.gold, fontSize:13, fontWeight:'700', marginLeft:5 }}>{points.toLocaleString()} pts</Text>
    </View>
  );
}

function OrderStatusBadge({ status }) {
  const MAP = { received:{color:T.warning,label:'Received'}, preparing:{color:T.info,label:'Preparing'}, ready:{color:T.success,label:'Ready'}, 'picked up':{color:T.ghost,label:'Done'} };
  const c = MAP[status] || MAP.received;
  return (
    <View style={{ paddingHorizontal:10, paddingVertical:3, borderRadius:T.r.full, backgroundColor:c.color+'22', borderWidth:1, borderColor:c.color+'55' }}>
      <Text style={{ color:c.color, fontSize:11, fontWeight:'700', textTransform:'uppercase' }}>{c.label}</Text>
    </View>
  );
}

// ═══════════════════════════════════════════════════════════════
// ROOT
// ═══════════════════════════════════════════════════════════════
export default function App() {
  const [auth, setAuth] = useState({ loggedIn:false, role:'', name:'' });
  const login  = (role, name) => setAuth({ loggedIn:true, role, name });
  const logout = () => Alert.alert('Sign Out','Are you sure?',[
    { text:'Cancel', style:'cancel' },
    { text:'Sign Out', style:'destructive', onPress:() => setAuth({ loggedIn:false, role:'', name:'' }) },
  ]);

  return (
    <>
      <StatusBar barStyle="light-content" backgroundColor={T.obsidian} />
      <NavigationContainer theme={{ dark:true, colors:{ primary:T.gold, background:T.obsidian, card:T.surface, text:T.cream, border:T.border, notification:T.danger } }}>
        <Stack.Navigator screenOptions={{ headerShown:false }}>
          {!auth.loggedIn
            ? <Stack.Screen name="Auth">{p     => <AuthScreen    {...p} onLogin={login} />}</Stack.Screen>
            : auth.role === 'manager'
            ? <Stack.Screen name="Manager">{p  => <ManagerApp    {...p} name={auth.name} onLogout={logout} />}</Stack.Screen>
            : <Stack.Screen name="Customer">{p => <CustomerApp   {...p} name={auth.name} onLogout={logout} />}</Stack.Screen>
          }
        </Stack.Navigator>
      </NavigationContainer>
    </>
  );
}

// ═══════════════════════════════════════════════════════════════
// AUTH — logo area compresses on signup so no scroll required
// ═══════════════════════════════════════════════════════════════
function AuthScreen({ onLogin }) {
  const [mode,     setMode]     = useState('login');
  const [email,    setEmail]    = useState('');
  const [password, setPassword] = useState('');
  const [name,     setName]     = useState('');
  const [phone,    setPhone]    = useState('');
  const [role,     setRole]     = useState('customer');
  const [showPass, setShowPass] = useState(false);
  const [loading,  setLoading]  = useState(false);

  const logoAnim   = useRef(new Animated.Value(0)).current;
  const shimmer    = useRef(new Animated.Value(0)).current;
  // logoHeight animates between large (login) and compact (signup)
  const logoHeight = useRef(new Animated.Value(SH * 0.28)).current;

  useEffect(() => {
    Animated.timing(logoAnim, { toValue:1, duration:1000, useNativeDriver:true }).start();
    Animated.loop(Animated.sequence([
      Animated.timing(shimmer, { toValue:1, duration:1800, useNativeDriver:true }),
      Animated.timing(shimmer, { toValue:0, duration:1800, useNativeDriver:true }),
    ])).start();
  }, []);

  useEffect(() => {
    // layout property — must use useNativeDriver:false
    Animated.timing(logoHeight, { toValue: mode === 'login' ? SH * 0.28 : SH * 0.16, duration:280, useNativeDriver:false }).start();
  }, [mode]);

  const submit = () => {
    if (!email.trim() || !password.trim()) { Alert.alert('Required','Please enter email and password.'); return; }
    if (mode === 'signup' && !name.trim())  { Alert.alert('Required','Please enter your full name.'); return; }
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      if (mode === 'login') {
        const isMgr = email.toLowerCase().includes('manager');
        onLogin(isMgr ? 'manager' : 'customer', isMgr ? 'Manager' : email.split('@')[0]);
      } else {
        onLogin(role, name.trim());
      }
    }, 1100);
  };

  const goldOpacity = shimmer.interpolate({ inputRange:[0,1], outputRange:[0.6,1] });

  return (
    <SafeAreaView style={{ flex:1, backgroundColor:T.obsidian }}>
      {/* Decorative rings */}
      <View style={StyleSheet.absoluteFill} pointerEvents="none">
        {[0,1,2,3,4,5].map(i => (
          <View key={i} style={{ position:'absolute', width:200+i*80, height:200+i*80, borderRadius:999, borderWidth:1, borderColor:T.gold+'08', top:SH/2-(100+i*40), left:SW/2-(100+i*40) }} />
        ))}
      </View>

      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex:1 }}>
        <ScrollView contentContainerStyle={{ flexGrow:1, paddingHorizontal:T.sp.lg, paddingBottom:T.sp.xl }} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>

          {/* Logo — outer view handles height (JS driver), inner handles opacity (native driver) */}
          <Animated.View style={{ height:logoHeight, alignItems:'center', justifyContent:'center' }}>
            <Animated.View style={{ opacity:logoAnim, alignItems:'center' }}>
              <Animated.View style={{ opacity:goldOpacity, width:64, height:64, borderRadius:32, backgroundColor:T.gold+'15', borderWidth:2, borderColor:T.gold+'40', alignItems:'center', justifyContent:'center', marginBottom:T.sp.sm }}>
                <Text style={{ fontSize:28 }}>✦</Text>
              </Animated.View>
              <Text style={{ fontSize:T.font.hero, fontWeight:'900', color:T.gold, letterSpacing:8, textTransform:'uppercase' }}>LUMIÈRE</Text>
              <Text style={{ color:T.ghost, fontSize:T.font.micro, letterSpacing:4, textTransform:'uppercase', marginTop:4 }}>Fine Dining Experience</Text>
            </Animated.View>
          </Animated.View>

          {/* Mode toggle */}
          <Reveal delay={150}>
            <View style={{ flexDirection:'row', backgroundColor:T.surface, borderRadius:T.r.md, borderWidth:1, borderColor:T.border, marginBottom:T.sp.xl, padding:4 }}>
              {['login','signup'].map(m => (
                <TouchableOpacity key={m} onPress={() => setMode(m)} style={{ flex:1, paddingVertical:12, borderRadius:T.r.sm+2, backgroundColor:mode===m ? T.gold : 'transparent', alignItems:'center' }}>
                  <Text style={{ color:mode===m ? T.obsidian : T.ghost, fontWeight:'700', fontSize:T.font.body }}>{m==='login' ? 'Sign In' : 'Create Account'}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </Reveal>

          {/* Form */}
          <Reveal delay={250}>
            {mode === 'signup' && (
              <>
                <LuxInput label="Full Name" icon="person-outline"  placeholder="Your name"         value={name}  onChangeText={setName}  autoCapitalize="words" />
                <LuxInput label="Phone"     icon="call-outline"    placeholder="+1 (555) 000-0000" value={phone} onChangeText={setPhone} keyboardType="phone-pad" />
              </>
            )}

            <LuxInput label="Email" icon="mail-outline" placeholder="your@email.com" value={email} onChangeText={setEmail} keyboardType="email-address" autoCapitalize="none" />

            {/* Password with show/hide toggle — extracted component */}
            <View style={{ marginBottom:T.sp.md }}>
              <Text style={{ color:T.gold, fontSize:T.font.micro, fontWeight:'700', letterSpacing:2, textTransform:'uppercase', marginBottom:8 }}>Password</Text>
              <PasswordInput value={password} onChange={setPassword} showPass={showPass} setShowPass={setShowPass} />
            </View>

            {mode === 'signup' && (
              <View style={{ marginBottom:T.sp.lg }}>
                <Text style={{ color:T.gold, fontSize:T.font.micro, fontWeight:'700', letterSpacing:2, textTransform:'uppercase', marginBottom:10 }}>I Am A</Text>
                <View style={{ flexDirection:'row' }}>
                  {[{ id:'customer', label:'Guest', icon:'person-outline' },{ id:'manager', label:'Staff', icon:'briefcase-outline' }].map((r, i) => (
                    <TouchableOpacity
                      key={r.id}
                      onPress={() => setRole(r.id)}
                      style={{ flex:1, flexDirection:'row', alignItems:'center', justifyContent:'center', paddingVertical:14, borderRadius:T.r.md, borderWidth:1.5, borderColor:role===r.id ? T.gold : T.border, backgroundColor:role===r.id ? T.gold+'15' : T.surface, marginLeft:i===1 ? T.sp.sm : 0 }}
                    >
                      <Ionicons name={r.icon} size={18} color={role===r.id ? T.gold : T.ghost} style={{ marginRight:6 }} />
                      <Text style={{ color:role===r.id ? T.gold : T.ghost, fontWeight:'700', fontSize:T.font.body }}>{r.label}</Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>
            )}

            <GoldButton label={mode==='login' ? 'Sign In' : 'Create Account'} onPress={submit} loading={loading} style={{ marginBottom:T.sp.lg }} />
          </Reveal>

          {/* Demo hint */}
          <Reveal delay={420}>
            <View style={{ backgroundColor:T.surface, borderRadius:T.r.md, borderWidth:1, borderColor:T.border, padding:T.sp.md }}>
              <Text style={{ color:T.gold, fontSize:T.font.micro, fontWeight:'700', letterSpacing:2, textTransform:'uppercase', marginBottom:8 }}>Demo Access</Text>
              <Text style={{ color:T.silver, fontSize:T.font.caption, lineHeight:20 }}>
                <Text style={{ color:T.cream }}>Guest:    </Text>guest@lumiere.com{'\n'}
                <Text style={{ color:T.cream }}>Manager:  </Text>manager@lumiere.com{'\n'}
                <Text style={{ color:T.cream }}>Password: </Text>anything works
              </Text>
            </View>
          </Reveal>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

/** Separated to avoid re-rendering entire form on each keystroke */
function PasswordInput({ value, onChange, showPass, setShowPass }) {
  const [focused, setFocused] = useState(false);
  return (
    <View style={{ flexDirection:'row', alignItems:'center', backgroundColor:T.surface, borderRadius:T.r.md, borderWidth:1, borderColor:focused ? T.gold : T.border, paddingHorizontal:T.sp.md, height:52 }}>
      <Ionicons name="lock-closed-outline" size={18} color={focused ? T.gold : T.ghost} style={{ marginRight:10 }} />
      <TextInput
        style={{ flex:1, color:T.cream, fontSize:T.font.body }}
        placeholder="••••••••" placeholderTextColor={T.ghost}
        secureTextEntry={!showPass} value={value} onChangeText={onChange}
        onFocus={() => setFocused(true)} onBlur={() => setFocused(false)}
      />
      <TouchableOpacity onPress={() => setShowPass(!showPass)}>
        <Ionicons name={showPass ? 'eye-off-outline' : 'eye-outline'} size={20} color={T.ghost} />
      </TouchableOpacity>
    </View>
  );
}

// ═══════════════════════════════════════════════════════════════
// CUSTOMER APP
// ═══════════════════════════════════════════════════════════════
function CustomerApp({ name, onLogout }) {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown:false,
        tabBarStyle:{ backgroundColor:T.surface, borderTopWidth:1, borderTopColor:T.border, height:80, paddingBottom:20, paddingTop:10 },
        tabBarActiveTintColor:T.gold,
        tabBarInactiveTintColor:T.ghost,
        tabBarLabelStyle:{ fontSize:10, fontWeight:'700', letterSpacing:0.5 },
        tabBarIcon:({ focused, color }) => {
          const icons = { Home:focused?'home':'home-outline', Explore:focused?'compass':'compass-outline', Reserve:focused?'calendar':'calendar-outline', Cart:focused?'cart':'cart-outline', Profile:focused?'person':'person-outline' };
          return <Ionicons name={icons[route.name]||'ellipse'} size={22} color={color} />;
        },
      })}
    >
      <Tab.Screen name="Home">{p    => <HomeScreen    {...p} name={name} onLogout={onLogout} />}</Tab.Screen>
      <Tab.Screen name="Explore"    component={ExploreScreen}     />
      <Tab.Screen name="Reserve"    component={ReservationScreen} />
      <Tab.Screen name="Cart"       component={CartScreen}        />
      <Tab.Screen name="Profile">{p => <ProfileScreen {...p} name={name} onLogout={onLogout} />}</Tab.Screen>
    </Tab.Navigator>
  );
}

// ═══════════════════════════════════════════════════════════════
// HOME
// ═══════════════════════════════════════════════════════════════
function HomeScreen({ name, onLogout }) {
  const [g] = useGlobal();
  const h   = new Date().getHours();
  const greet = h < 12 ? 'Good Morning' : h < 17 ? 'Good Afternoon' : 'Good Evening';

  return (
    <SafeAreaView style={{ flex:1, backgroundColor:T.obsidian }}>
      <ScrollView showsVerticalScrollIndicator={false}>

        <Reveal>
          <View style={{ paddingHorizontal:T.sp.lg, paddingTop:T.sp.lg, flexDirection:'row', justifyContent:'space-between', alignItems:'flex-start', marginBottom:T.sp.xl }}>
            <View>
              <Text style={{ color:T.ghost, fontSize:T.font.caption, letterSpacing:1, marginBottom:3 }}>{greet}</Text>
              <Text style={{ color:T.cream, fontSize:T.font.heading, fontWeight:'800' }}>{name||'Guest'} ✦</Text>
            </View>
            <View style={{ flexDirection:'row', alignItems:'center' }}>
              <LoyaltyBadge points={g.loyalty} />
              <TouchableOpacity onPress={onLogout} style={{ marginLeft:10, width:40, height:40, borderRadius:20, backgroundColor:T.elevated, borderWidth:1, borderColor:T.border, alignItems:'center', justifyContent:'center' }}>
                <Ionicons name="log-out-outline" size={18} color={T.ghost} />
              </TouchableOpacity>
            </View>
          </View>
        </Reveal>

        {/* Specials */}
        <View style={{ marginBottom:T.sp.xl }}>
          <Reveal>
            <View style={{ paddingHorizontal:T.sp.lg, flexDirection:'row', justifyContent:'space-between', alignItems:'center', marginBottom:T.sp.md }}>
              <Text style={{ color:T.cream, fontSize:T.font.title, fontWeight:'800' }}>Tonight's Specials</Text>
              <Badge label="SEASONAL" color={T.success} />
            </View>
          </Reveal>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ paddingLeft:T.sp.lg, paddingRight:T.sp.md }}>
            {FEATURED.map((item, i) => <Reveal key={item.id} delay={i*100}><FeaturedCard item={item} /></Reveal>)}
          </ScrollView>
        </View>

        {/* Live stats */}
        <Reveal delay={150}>
          <View style={{ flexDirection:'row', paddingHorizontal:T.sp.lg, marginBottom:T.sp.xl }}>
            {[{label:'Tables',value:'4 left',icon:'people-outline',color:T.success},{label:'Wait',value:'~20 min',icon:'time-outline',color:T.warning},{label:'Open',value:'Until 11',icon:'moon-outline',color:T.info}].map((s, i) => (
              <View key={s.label} style={{ flex:1, backgroundColor:T.elevated, borderRadius:T.r.md, borderWidth:1, borderColor:T.border, padding:T.sp.md, alignItems:'center', marginLeft:i>0?T.sp.sm:0 }}>
                <Ionicons name={s.icon} size={20} color={s.color} />
                <Text style={{ color:T.cream, fontSize:13, fontWeight:'700', marginTop:4 }}>{s.value}</Text>
                <Text style={{ color:T.ghost, fontSize:10, letterSpacing:0.5, marginTop:2 }}>{s.label.toUpperCase()}</Text>
              </View>
            ))}
          </View>
        </Reveal>

        {/* Quick actions */}
        <Reveal delay={220}>
          <View style={{ paddingHorizontal:T.sp.lg, marginBottom:T.sp.xl }}>
            <Text style={{ color:T.cream, fontSize:T.font.title, fontWeight:'800', marginBottom:T.sp.md }}>Quick Actions</Text>
            <View style={{ flexDirection:'row' }}>
              {[{label:'Reserve Table',icon:'calendar',colors:[T.gold,'#A07830']},{label:'Order Now',icon:'restaurant',colors:['#4ECDA4','#35A080']}].map((a, i) => (
                <TouchableOpacity key={a.label} style={{ flex:1, marginLeft:i>0?T.sp.sm:0 }}>
                  <LinearGradient colors={a.colors} start={{x:0,y:0}} end={{x:1,y:1}} style={{ borderRadius:T.r.lg, padding:T.sp.lg, height:100, justifyContent:'space-between' }}>
                    <Ionicons name={a.icon} size={28} color="rgba(0,0,0,0.55)" />
                    <Text style={{ color:T.obsidian, fontSize:14, fontWeight:'800' }}>{a.label}</Text>
                  </LinearGradient>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        </Reveal>

        {/* Most loved */}
        <Reveal delay={300}>
          <View style={{ paddingHorizontal:T.sp.lg, marginBottom:40 }}>
            <Text style={{ color:T.cream, fontSize:T.font.title, fontWeight:'800', marginBottom:T.sp.md }}>Most Loved</Text>
            {g.menuItems.slice(0,5).map((item, i) => <CompactMenuItem key={item.id} item={item} delay={i*60} />)}
          </View>
        </Reveal>

      </ScrollView>
    </SafeAreaView>
  );
}

function FeaturedCard({ item }) {
  const scale  = useRef(new Animated.Value(1)).current;
  const [added, setAdded] = useState(false);
  const add = () => {
    updateG(s => ({ cart:[...s.cart, { ...item, cartId:Date.now() }], loyalty:s.loyalty + Math.floor(item.price) }));
    setAdded(true);
    Animated.sequence([
      Animated.timing(scale, { toValue:0.93, duration:80,  useNativeDriver:true }),
      Animated.spring(scale, { toValue:1,    tension:200, friction:7, useNativeDriver:true }),
    ]).start();
  };
  return (
    <Animated.View style={{ transform:[{scale}], marginRight:T.sp.md, width:SW*0.68 }}>
      <Card glow>
        <View style={{ padding:T.sp.lg }}>
          <View style={{ flexDirection:'row', justifyContent:'space-between', alignItems:'flex-start', marginBottom:T.sp.sm }}>
            <Text style={{ fontSize:50 }}>{item.emoji}</Text>
            <View style={{ alignItems:'flex-end' }}>
              {item.tags.slice(0,2).map(t => <Badge key={t} label={t} style={{ marginBottom:4 }} />)}
            </View>
          </View>
          <Text style={{ color:T.cream, fontSize:T.font.title, fontWeight:'800', marginBottom:2 }}>{item.name}</Text>
          <Text style={{ color:T.ghost, fontSize:T.font.caption, marginBottom:T.sp.sm }}>{item.subtitle}</Text>
          <Stars rating={item.rating} reviews={item.reviews} />
          <Divider style={{ marginVertical:T.sp.sm }} />
          <View style={{ flexDirection:'row', justifyContent:'space-between', alignItems:'center' }}>
            <Text style={{ color:T.gold, fontSize:T.font.title, fontWeight:'900' }}>${item.price.toFixed(2)}</Text>
            <TouchableOpacity onPress={add} style={{ width:38, height:38, borderRadius:19, backgroundColor:added?T.success+'22':T.gold+'22', borderWidth:1, borderColor:added?T.success:T.gold, alignItems:'center', justifyContent:'center' }}>
              <Ionicons name={added?'checkmark':'add'} size={20} color={added?T.success:T.gold} />
            </TouchableOpacity>
          </View>
        </View>
      </Card>
    </Animated.View>
  );
}

function CompactMenuItem({ item, delay }) {
  const [qty, setQty] = useState(0);
  const add = () => {
    setQty(q => q+1);
    updateG(s => ({ cart:[...s.cart, { ...item, cartId:Date.now() }], loyalty:s.loyalty + Math.floor(item.price) }));
  };
  const rem = () => {
    if (qty===0) return;
    setQty(q => q-1);
    updateG(s => {
      const cart = [...s.cart];
      const idx  = lastIndexOf(cart, c => c.id === item.id);
      if (idx !== -1) cart.splice(idx, 1);
      return { cart };
    });
  };
  return (
    <Reveal delay={delay}>
      <Card style={{ marginBottom:T.sp.sm }}>
        <View style={{ flexDirection:'row', alignItems:'center', padding:T.sp.md }}>
          <View style={{ width:58, height:58, borderRadius:T.r.md, backgroundColor:T.surface, alignItems:'center', justifyContent:'center', marginRight:T.sp.md }}>
            <Text style={{ fontSize:28 }}>{item.emoji}</Text>
          </View>
          <View style={{ flex:1 }}>
            <Text style={{ color:T.cream, fontSize:15, fontWeight:'700', marginBottom:3 }}>{item.name}</Text>
            <Stars rating={item.rating} reviews={item.reviews} />
          </View>
          <View style={{ alignItems:'flex-end' }}>
            <Text style={{ color:T.gold, fontSize:15, fontWeight:'800', marginBottom:6 }}>${item.price.toFixed(2)}</Text>
            {qty===0
              ? <TouchableOpacity onPress={add} style={{ paddingHorizontal:12, paddingVertical:5, backgroundColor:T.gold+'22', borderRadius:T.r.full, borderWidth:1, borderColor:T.gold+'55' }}>
                  <Text style={{ color:T.gold, fontSize:12, fontWeight:'700' }}>ADD</Text>
                </TouchableOpacity>
              : <View style={{ flexDirection:'row', alignItems:'center' }}>
                  <TouchableOpacity onPress={rem}><Ionicons name="remove-circle" size={26} color={T.gold} /></TouchableOpacity>
                  <Text style={{ color:T.cream, fontSize:15, fontWeight:'700', marginHorizontal:8, minWidth:16, textAlign:'center' }}>{qty}</Text>
                  <TouchableOpacity onPress={add}><Ionicons name="add-circle" size={26} color={T.gold} /></TouchableOpacity>
                </View>
            }
          </View>
        </View>
      </Card>
    </Reveal>
  );
}

// ═══════════════════════════════════════════════════════════════
// EXPLORE
// ═══════════════════════════════════════════════════════════════
function ExploreScreen() {
  const [g]           = useGlobal();
  const [cat,    setCat]    = useState('all');
  const [search, setSearch] = useState('');
  const [detail, setDetail] = useState(null);

  const filtered = g.menuItems.filter(item => {
    const okCat    = cat === 'all' || item.category === cat;
    const okSearch = !search || item.name.toLowerCase().includes(search.toLowerCase());
    return okCat && okSearch;
  });

  return (
    <SafeAreaView style={{ flex:1, backgroundColor:T.obsidian }}>
      <Header title="Menu" subtitle="Lumière" />

      <View style={{ paddingHorizontal:T.sp.lg, marginBottom:T.sp.md }}>
        <View style={{ flexDirection:'row', alignItems:'center', backgroundColor:T.elevated, borderRadius:T.r.md, borderWidth:1, borderColor:T.border, paddingHorizontal:T.sp.md, height:46 }}>
          <Ionicons name="search-outline" size={18} color={T.ghost} style={{ marginRight:8 }} />
          <TextInput style={{ flex:1, color:T.cream, fontSize:T.font.body }} placeholder="Search dishes, wines…" placeholderTextColor={T.ghost} value={search} onChangeText={setSearch} />
          {search ? <TouchableOpacity onPress={() => setSearch('')}><Ionicons name="close-circle" size={18} color={T.ghost} /></TouchableOpacity> : null}
        </View>
      </View>

      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ maxHeight:44, marginBottom:T.sp.md }} contentContainerStyle={{ paddingHorizontal:T.sp.lg }}>
        {CATEGORIES.map((c, i) => (
          <TouchableOpacity key={c.id} onPress={() => setCat(c.id)} style={{ flexDirection:'row', alignItems:'center', paddingHorizontal:14, height:36, borderRadius:T.r.full, backgroundColor:cat===c.id?T.gold:T.elevated, borderWidth:1, borderColor:cat===c.id?T.gold:T.border, marginLeft:i>0?T.sp.sm:0 }}>
            <Text style={{ fontSize:13 }}>{c.icon}</Text>
            <Text style={{ color:cat===c.id?T.obsidian:T.silver, fontSize:13, fontWeight:'700', marginLeft:5 }}>{c.name}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      <FlatList
        data={filtered}
        keyExtractor={item => item.id}
        contentContainerStyle={{ paddingHorizontal:T.sp.lg, paddingBottom:20 }}
        showsVerticalScrollIndicator={false}
        renderItem={({ item, index }) => (
          <Reveal delay={index*45}>
            <TouchableOpacity onPress={() => setDetail(item)} activeOpacity={0.9}>
              <Card style={{ marginBottom:T.sp.sm }}>
                <View style={{ padding:T.sp.md, flexDirection:'row', alignItems:'center' }}>
                  <View style={{ width:68, height:68, borderRadius:T.r.md, backgroundColor:T.surface, alignItems:'center', justifyContent:'center', borderWidth:1, borderColor:T.border, marginRight:T.sp.md }}>
                    <Text style={{ fontSize:34 }}>{item.emoji}</Text>
                  </View>
                  <View style={{ flex:1 }}>
                    <View style={{ flexDirection:'row', alignItems:'flex-start', justifyContent:'space-between', marginBottom:2 }}>
                      <Text style={{ color:T.cream, fontSize:15, fontWeight:'800', flex:1, marginRight:8 }}>{item.name}</Text>
                      <Text style={{ color:T.gold, fontSize:15, fontWeight:'900' }}>${item.price.toFixed(2)}</Text>
                    </View>
                    <Text style={{ color:T.ghost, fontSize:12, marginBottom:5 }}>{item.subtitle}</Text>
                    <View style={{ flexDirection:'row', alignItems:'center' }}>
                      <Stars rating={item.rating} reviews={item.reviews} />
                      <Text style={{ color:T.muted, fontSize:12, marginHorizontal:6 }}>·</Text>
                      <Text style={{ color:T.ghost, fontSize:12 }}>{item.prepTime}min</Text>
                      {item.tags[0] ? <Badge label={item.tags[0]} style={{ marginLeft:6 }} /> : null}
                    </View>
                  </View>
                </View>
              </Card>
            </TouchableOpacity>
          </Reveal>
        )}
        ListEmptyComponent={
          <View style={{ alignItems:'center', paddingVertical:60 }}>
            <Text style={{ fontSize:40, marginBottom:12 }}>🔍</Text>
            <Text style={{ color:T.ghost, fontSize:T.font.body }}>No dishes found</Text>
          </View>
        }
      />

      <Sheet visible={!!detail} onClose={() => setDetail(null)} title={detail?.name}>
        {detail ? <ItemDetailSheet item={detail} onClose={() => setDetail(null)} /> : null}
      </Sheet>
    </SafeAreaView>
  );
}

function ItemDetailSheet({ item, onClose }) {
  const [qty,   setQty]   = useState(1);
  const [notes, setNotes] = useState('');
  const add = () => {
    for (let i = 0; i < qty; i++) {
      updateG(s => ({ cart:[...s.cart, { ...item, cartId:Date.now()+i }], loyalty:s.loyalty+Math.floor(item.price) }));
    }
    Alert.alert('Added!',`${qty}× ${item.name} added to cart.`);
    onClose();
  };
  return (
    <ScrollView contentContainerStyle={{ paddingHorizontal:T.sp.lg, paddingBottom:T.sp.md }} showsVerticalScrollIndicator={false}>
      <View style={{ alignItems:'center', marginBottom:T.sp.lg }}>
        <View style={{ width:110, height:110, borderRadius:55, backgroundColor:T.elevated, borderWidth:2, borderColor:T.gold+'33', alignItems:'center', justifyContent:'center' }}>
          <Text style={{ fontSize:56 }}>{item.emoji}</Text>
        </View>
      </View>
      <View style={{ flexDirection:'row', marginBottom:T.sp.md, flexWrap:'wrap' }}>
        {item.tags.map(t => <Badge key={t} label={t} style={{ marginRight:6, marginBottom:4 }} />)}
      </View>
      <Text style={{ color:T.silver, fontSize:T.font.body, lineHeight:24, marginBottom:T.sp.lg }}>{item.description}</Text>
      <View style={{ flexDirection:'row', backgroundColor:T.surface, borderRadius:T.r.md, borderWidth:1, borderColor:T.border, marginBottom:T.sp.lg, overflow:'hidden' }}>
        {[{icon:'flame-outline',label:`${item.calories} cal`},{icon:'time-outline',label:`${item.prepTime} min`},{icon:'star-outline',label:`${item.rating}`}].map((info, i) => (
          <View key={i} style={{ flex:1, alignItems:'center', paddingVertical:T.sp.md, borderRightWidth:i<2?1:0, borderRightColor:T.border }}>
            <Ionicons name={info.icon} size={18} color={T.gold} />
            <Text style={{ color:T.cream, fontSize:13, fontWeight:'700', marginTop:4 }}>{info.label}</Text>
          </View>
        ))}
      </View>
      {item.allergens.length > 0 ? <Text style={{ color:T.ghost, fontSize:12, marginBottom:T.sp.lg }}>Contains: {item.allergens.join(', ')}</Text> : null}
      <LuxInput label="Special Notes (optional)" icon="create-outline" placeholder="Allergies, preferences…" value={notes} onChangeText={setNotes} />
      <View style={{ flexDirection:'row', alignItems:'center', marginBottom:T.sp.lg }}>
        <View style={{ flexDirection:'row', alignItems:'center', backgroundColor:T.elevated, borderRadius:T.r.md, borderWidth:1, borderColor:T.border, paddingHorizontal:T.sp.md, height:54, marginRight:T.sp.md }}>
          <TouchableOpacity onPress={() => setQty(q => Math.max(1,q-1))}><Ionicons name="remove" size={20} color={T.gold} /></TouchableOpacity>
          <Text style={{ color:T.cream, fontSize:T.font.title, fontWeight:'800', marginHorizontal:16, minWidth:24, textAlign:'center' }}>{qty}</Text>
          <TouchableOpacity onPress={() => setQty(q => q+1)}><Ionicons name="add" size={20} color={T.gold} /></TouchableOpacity>
        </View>
        <GoldButton label={`Add · $${(item.price*qty).toFixed(2)}`} onPress={add} style={{ flex:1 }} />
      </View>
    </ScrollView>
  );
}

// ═══════════════════════════════════════════════════════════════
// RESERVATION
// ═══════════════════════════════════════════════════════════════
function ReservationScreen() {
  const [g, upd]   = useGlobal();
  const [date,     setDate]     = useState('');
  const [time,     setTime]     = useState('');
  const [size,     setSize]     = useState(2);
  const [name,     setName]     = useState('');
  const [phone,    setPhone]    = useState('');
  const [occasion, setOccasion] = useState('');
  const [loading,  setLoading]  = useState(false);
  const OCCASIONS = ['None','Birthday 🎂','Anniversary 💍','Business 💼','Date Night 🌹'];

  const book = () => {
    if (!date||!time||!name||!phone) { Alert.alert('Missing Info','Please fill in all required fields.'); return; }
    setLoading(true);
    setTimeout(() => {
      upd(s => ({
        reservations:[...s.reservations,{ id:`RES-${Date.now()}`, date, time, partySize:size, name, phone, occasion:occasion==='None'?'':occasion, status:'pending', created:new Date().toLocaleString() }],
        loyalty:s.loyalty+100,
      }));
      setLoading(false);
      setDate(''); setTime(''); setName(''); setPhone(''); setOccasion(''); setSize(2);
      Alert.alert('✦ Reservation Requested','Confirmation within 15 minutes.\n\n+100 loyalty points!');
    }, 1400);
  };

  return (
    <SafeAreaView style={{ flex:1, backgroundColor:T.obsidian }}>
      <Header title="Reserve" subtitle="Book a Table" />
      <ScrollView contentContainerStyle={{ paddingHorizontal:T.sp.lg, paddingBottom:40 }} showsVerticalScrollIndicator={false}>
        <Reveal>
          <Card style={{ padding:T.sp.lg, marginBottom:T.sp.lg }}>
            <Text style={{ color:T.gold, fontSize:T.font.micro, fontWeight:'700', letterSpacing:2, textTransform:'uppercase', marginBottom:T.sp.md }}>Reservation Details</Text>
            <LuxInput label="Your Name" icon="person-outline"   placeholder="Full name"         value={name}  onChangeText={setName}  autoCapitalize="words" />
            <LuxInput label="Phone"     icon="call-outline"     placeholder="+1 (555) 000-0000" value={phone} onChangeText={setPhone} keyboardType="phone-pad" />
            <LuxInput label="Date"      icon="calendar-outline" placeholder="MM/DD/YYYY"        value={date}  onChangeText={setDate} />

            <View style={{ marginBottom:T.sp.md }}>
              <Text style={{ color:T.gold, fontSize:T.font.micro, fontWeight:'700', letterSpacing:2, textTransform:'uppercase', marginBottom:10 }}>Preferred Time</Text>
              <View style={{ flexDirection:'row', flexWrap:'wrap' }}>
                {TIME_SLOTS.map(slot => (
                  <TouchableOpacity key={slot} onPress={() => setTime(slot)} style={{ paddingHorizontal:12, paddingVertical:7, borderRadius:T.r.full, borderWidth:1, borderColor:time===slot?T.gold:T.border, backgroundColor:time===slot?T.gold+'18':T.surface, marginRight:T.sp.sm, marginBottom:T.sp.sm }}>
                    <Text style={{ color:time===slot?T.gold:T.ghost, fontSize:13, fontWeight:'600' }}>{slot}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>

            <View style={{ marginBottom:T.sp.md }}>
              <Text style={{ color:T.gold, fontSize:T.font.micro, fontWeight:'700', letterSpacing:2, textTransform:'uppercase', marginBottom:10 }}>Party Size</Text>
              <View style={{ flexDirection:'row', alignItems:'center' }}>
                <TouchableOpacity onPress={() => setSize(s => Math.max(1,s-1))}><Ionicons name="remove-circle-outline" size={36} color={T.gold} /></TouchableOpacity>
                <View style={{ alignItems:'center', marginHorizontal:T.sp.lg }}>
                  <Text style={{ color:T.cream, fontSize:32, fontWeight:'900' }}>{size}</Text>
                  <Text style={{ color:T.ghost, fontSize:12 }}>{size===1?'Guest':'Guests'}</Text>
                </View>
                <TouchableOpacity onPress={() => setSize(s => Math.min(20,s+1))}><Ionicons name="add-circle-outline" size={36} color={T.gold} /></TouchableOpacity>
              </View>
            </View>

            <View style={{ marginBottom:T.sp.lg }}>
              <Text style={{ color:T.gold, fontSize:T.font.micro, fontWeight:'700', letterSpacing:2, textTransform:'uppercase', marginBottom:10 }}>Occasion</Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                {OCCASIONS.map((occ, i) => {
                  const val = occ==='None' ? '' : occ;
                  return (
                    <TouchableOpacity key={occ} onPress={() => setOccasion(val)} style={{ paddingHorizontal:14, paddingVertical:8, borderRadius:T.r.full, borderWidth:1, borderColor:occasion===val?T.gold:T.border, backgroundColor:occasion===val?T.gold+'18':T.surface, marginLeft:i>0?T.sp.sm:0 }}>
                      <Text style={{ color:occasion===val?T.gold:T.ghost, fontSize:13 }}>{occ}</Text>
                    </TouchableOpacity>
                  );
                })}
              </ScrollView>
            </View>

            <GoldButton label="Request Reservation" onPress={book} loading={loading} icon="calendar-outline" />
          </Card>
        </Reveal>

        {g.reservations.length > 0 && (
          <Reveal delay={150}>
            <Text style={{ color:T.cream, fontSize:T.font.title, fontWeight:'800', marginBottom:T.sp.md }}>My Reservations</Text>
            {g.reservations.map(res => (
              <Card key={res.id} style={{ marginBottom:T.sp.sm }}>
                <View style={{ padding:T.sp.md }}>
                  <View style={{ flexDirection:'row', justifyContent:'space-between', alignItems:'flex-start', marginBottom:5 }}>
                    <Text style={{ color:T.cream, fontSize:15, fontWeight:'700' }}>{res.name}</Text>
                    <View style={{ paddingHorizontal:10, paddingVertical:3, borderRadius:T.r.full, backgroundColor:res.status==='confirmed'?T.success+'22':T.warning+'22' }}>
                      <Text style={{ color:res.status==='confirmed'?T.success:T.warning, fontSize:11, fontWeight:'700', textTransform:'uppercase' }}>{res.status}</Text>
                    </View>
                  </View>
                  <Text style={{ color:T.ghost, fontSize:13 }}>{res.date} · {res.time} · Party of {res.partySize}</Text>
                  {res.occasion ? <Text style={{ color:T.gold, fontSize:12, marginTop:3 }}>{res.occasion}</Text> : null}
                  <Text style={{ color:T.muted, fontSize:11, marginTop:4 }}>{res.id}</Text>
                </View>
              </Card>
            ))}
          </Reveal>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

// ═══════════════════════════════════════════════════════════════
// CART
// ═══════════════════════════════════════════════════════════════
function CartScreen() {
  const [g, upd]  = useGlobal();
  const [pickup,  setPickup]  = useState('');
  const [loading, setLoading] = useState(false);

  // Group cart entries by item id
  const grouped = g.cart.reduce((acc, ci) => {
    const ex = acc.find(a => a.id === ci.id);
    if (ex) ex.qty++;
    else     acc.push({ ...ci, qty:1 });
    return acc;
  }, []);

  const subtotal = g.cart.reduce((s, i) => s + i.price, 0);
  const tax      = subtotal * 0.08;
  const service  = subtotal * 0.18;
  const total    = subtotal + tax + service;

  /** Add one more of an item */
  const addOne = (item) => upd(s => ({ cart:[...s.cart, { ...item, cartId:Date.now() }] }));

  /** Remove the last occurrence in the cart array that matches itemId */
  const removeOne = (itemId) => {
    upd(s => {
      const cart = [...s.cart];
      const idx  = lastIndexOf(cart, c => c.id === itemId);
      if (idx !== -1) cart.splice(idx, 1);
      return { cart };
    });
  };

  /** Remove ALL occurrences of this itemId */
  const clearItem = (itemId) => upd(s => ({ cart:s.cart.filter(c => c.id !== itemId) }));

  const placeOrder = () => {
    if (g.cart.length === 0) { Alert.alert('Empty Cart','Add some items first.'); return; }
    if (!pickup)              { Alert.alert('Pickup Time','Please select a time.'); return; }
    setLoading(true);
    setTimeout(() => {
      const orderId = `ORD-${Math.floor(Math.random()*9000)+1000}`;
      upd(s => ({
        cart:[],
        loyalty:s.loyalty+Math.floor(total),
        orders:[...s.orders,{ id:orderId, customer:'You', table:'Takeout', items:grouped.map(i=>({name:i.name,qty:i.qty,price:i.price})), total, status:'received', time:pickup, notes:'', priority:'normal' }],
      }));
      setLoading(false);
      setPickup('');
      Alert.alert(`✦ Order ${orderId}`,`Total: $${total.toFixed(2)}\nPickup: ${pickup}\n+${Math.floor(total)} loyalty pts!`);
    }, 1600);
  };

  if (g.cart.length === 0) {
    return (
      <SafeAreaView style={{ flex:1, backgroundColor:T.obsidian }}>
        <Header title="Cart" subtitle="Your Order" />
        <View style={{ flex:1, alignItems:'center', justifyContent:'center' }}>
          <Text style={{ fontSize:64, marginBottom:T.sp.lg }}>🛒</Text>
          <Text style={{ color:T.cream, fontSize:T.font.title, fontWeight:'700', marginBottom:8 }}>Your cart is empty</Text>
          <Text style={{ color:T.ghost, fontSize:T.font.body }}>Explore the menu to add dishes</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={{ flex:1, backgroundColor:T.obsidian }}>
      <Header title={`Cart (${g.cart.length})`} subtitle="Your Order" />
      <ScrollView contentContainerStyle={{ paddingHorizontal:T.sp.lg, paddingBottom:40 }} showsVerticalScrollIndicator={false}>

        <Reveal>
          <Card style={{ marginBottom:T.sp.lg }}>
            {grouped.map((item, idx) => (
              <View key={item.id}>
                <View style={{ flexDirection:'row', alignItems:'center', padding:T.sp.md }}>
                  <View style={{ width:48, height:48, borderRadius:T.r.md, backgroundColor:T.surface, alignItems:'center', justifyContent:'center', marginRight:T.sp.md }}>
                    <Text style={{ fontSize:24 }}>{item.emoji}</Text>
                  </View>
                  <View style={{ flex:1 }}>
                    <Text style={{ color:T.cream, fontSize:14, fontWeight:'700' }}>{item.name}</Text>
                    <Text style={{ color:T.ghost, fontSize:12 }}>${item.price.toFixed(2)} each</Text>
                  </View>
                  <View style={{ flexDirection:'row', alignItems:'center', marginRight:T.sp.sm }}>
                    <TouchableOpacity onPress={() => removeOne(item.id)}><Ionicons name="remove-circle-outline" size={22} color={T.gold} /></TouchableOpacity>
                    <Text style={{ color:T.cream, fontSize:15, fontWeight:'800', marginHorizontal:8, minWidth:18, textAlign:'center' }}>{item.qty}</Text>
                    <TouchableOpacity onPress={() => addOne(item)}><Ionicons name="add-circle-outline" size={22} color={T.gold} /></TouchableOpacity>
                  </View>
                  <View style={{ alignItems:'flex-end' }}>
                    <Text style={{ color:T.gold, fontSize:14, fontWeight:'800', marginBottom:4 }}>${(item.price*item.qty).toFixed(2)}</Text>
                    <TouchableOpacity onPress={() => clearItem(item.id)}><Ionicons name="trash-outline" size={18} color={T.danger+'AA'} /></TouchableOpacity>
                  </View>
                </View>
                {idx < grouped.length-1 && <Divider />}
              </View>
            ))}
          </Card>
        </Reveal>

        <Reveal delay={80}>
          <Card style={{ padding:T.sp.lg, marginBottom:T.sp.lg }}>
            <Text style={{ color:T.gold, fontSize:T.font.micro, fontWeight:'700', letterSpacing:2, textTransform:'uppercase', marginBottom:T.sp.md }}>Summary</Text>
            {[['Subtotal',subtotal],['Tax (8%)',tax],['Service (18%)',service]].map(([label,val]) => (
              <View key={label} style={{ flexDirection:'row', justifyContent:'space-between', marginBottom:8 }}>
                <Text style={{ color:T.ghost,  fontSize:T.font.body }}>{label}</Text>
                <Text style={{ color:T.silver, fontSize:T.font.body }}>${val.toFixed(2)}</Text>
              </View>
            ))}
            <Divider style={{ marginVertical:T.sp.sm }} />
            <View style={{ flexDirection:'row', justifyContent:'space-between' }}>
              <Text style={{ color:T.cream, fontSize:T.font.title, fontWeight:'800' }}>Total</Text>
              <Text style={{ color:T.gold,  fontSize:T.font.title, fontWeight:'900' }}>${total.toFixed(2)}</Text>
            </View>
            <View style={{ flexDirection:'row', alignItems:'center', marginTop:T.sp.sm }}>
              <Ionicons name="diamond-outline" size={14} color={T.gold} style={{ marginRight:5 }} />
              <Text style={{ color:T.gold, fontSize:12 }}>You'll earn +{Math.floor(total)} loyalty points</Text>
            </View>
          </Card>
        </Reveal>

        <Reveal delay={140}>
          <Card style={{ marginBottom:T.sp.lg }}>
            <View style={{ padding:T.sp.lg }}>
              <Text style={{ color:T.gold, fontSize:T.font.micro, fontWeight:'700', letterSpacing:2, textTransform:'uppercase', marginBottom:T.sp.md }}>Pickup Time</Text>
              <View style={{ flexDirection:'row', flexWrap:'wrap' }}>
                {TIME_SLOTS.map(slot => (
                  <TouchableOpacity key={slot} onPress={() => setPickup(slot)} style={{ paddingHorizontal:12, paddingVertical:7, borderRadius:T.r.full, borderWidth:1, borderColor:pickup===slot?T.gold:T.border, backgroundColor:pickup===slot?T.gold+'18':T.surface, marginRight:T.sp.sm, marginBottom:T.sp.sm }}>
                    <Text style={{ color:pickup===slot?T.gold:T.ghost, fontSize:13, fontWeight:'600' }}>{slot}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>
          </Card>
        </Reveal>

        <Reveal delay={200}>
          <GoldButton label={`Place Order · $${total.toFixed(2)}`} onPress={placeOrder} loading={loading} icon="checkmark-circle-outline" />
        </Reveal>

      </ScrollView>
    </SafeAreaView>
  );
}

// ═══════════════════════════════════════════════════════════════
// PROFILE
// ═══════════════════════════════════════════════════════════════
function ProfileScreen({ name, onLogout }) {
  const [g]             = useGlobal();
  const [notif, setNotif] = useState(true);
  const [news,  setNews]  = useState(false);

  const tier = g.loyalty < 500  ? { name:'Bronze',  next:500,  color:'#CD7F32' }
             : g.loyalty < 1500 ? { name:'Silver',  next:1500, color:'#C0C0C0' }
             : g.loyalty < 3000 ? { name:'Gold',    next:3000, color:T.gold    }
             :                    { name:'Platinum',next:null, color:'#E5E4E2'  };
  const prog = tier.next ? Math.min(g.loyalty/tier.next, 1) : 1;

  return (
    <SafeAreaView style={{ flex:1, backgroundColor:T.obsidian }}>
      <Header title="Profile" subtitle="Lumière" />
      <ScrollView contentContainerStyle={{ paddingHorizontal:T.sp.lg, paddingBottom:40 }} showsVerticalScrollIndicator={false}>

        <Reveal>
          <View style={{ alignItems:'center', marginBottom:T.sp.xl }}>
            <View style={{ width:88, height:88, borderRadius:44, backgroundColor:T.gold+'22', borderWidth:2, borderColor:T.gold+'55', alignItems:'center', justifyContent:'center', marginBottom:T.sp.md }}>
              <Text style={{ fontSize:38 }}>👤</Text>
            </View>
            <Text style={{ color:T.cream, fontSize:T.font.heading, fontWeight:'800' }}>{name||'Guest'}</Text>
            <Text style={{ color:T.ghost, fontSize:T.font.caption, marginTop:4 }}>Lumière Member</Text>
          </View>
        </Reveal>

        <Reveal delay={100}>
          <LinearGradient colors={['#1A1508','#2A2010']} style={{ borderRadius:T.r.lg, padding:T.sp.lg, borderWidth:1, borderColor:T.gold+'44', marginBottom:T.sp.lg }}>
            <View style={{ flexDirection:'row', justifyContent:'space-between', alignItems:'flex-start', marginBottom:T.sp.md }}>
              <View>
                <Text style={{ color:T.goldDim, fontSize:T.font.micro, fontWeight:'700', letterSpacing:2, textTransform:'uppercase' }}>Loyalty Status</Text>
                <Text style={{ color:T.gold, fontSize:T.font.heading, fontWeight:'900' }}>{tier.name}</Text>
              </View>
              <Ionicons name="diamond" size={36} color={tier.color} />
            </View>
            <Text style={{ color:T.goldLight, fontSize:28, fontWeight:'900', marginBottom:4 }}>
              {g.loyalty.toLocaleString()}<Text style={{ fontSize:14, fontWeight:'600', color:T.goldDim }}> points</Text>
            </Text>
            {tier.next
              ? <>
                  <View style={{ height:6, backgroundColor:T.gold+'22', borderRadius:3, marginTop:T.sp.sm, overflow:'hidden' }}>
                    <View style={{ height:'100%', width:`${prog*100}%`, backgroundColor:T.gold, borderRadius:3 }} />
                  </View>
                  <Text style={{ color:T.goldDim, fontSize:11, marginTop:6 }}>{(tier.next-g.loyalty).toLocaleString()} pts to next tier</Text>
                </>
              : null
            }
          </LinearGradient>
        </Reveal>

        <Reveal delay={180}>
          <View style={{ flexDirection:'row', marginBottom:T.sp.lg }}>
            {[['Orders',g.orders.length],['Reservations',g.reservations.length],['Reviews',0]].map(([label,val], i) => (
              <Card key={label} style={{ flex:1, alignItems:'center', padding:T.sp.md, marginLeft:i>0?T.sp.sm:0 }}>
                <Text style={{ color:T.cream, fontSize:T.font.heading, fontWeight:'900' }}>{val}</Text>
                <Text style={{ color:T.ghost, fontSize:11, marginTop:2 }}>{label}</Text>
              </Card>
            ))}
          </View>
        </Reveal>

        <Reveal delay={250}>
          <Card style={{ marginBottom:T.sp.lg }}>
            {[
              { label:'Push Notifications', icon:'notifications-outline', toggle:true,  value:notif, onChange:setNotif },
              { label:'Newsletter',          icon:'mail-outline',          toggle:true,  value:news,  onChange:setNews  },
              { label:'Dietary Preferences', icon:'leaf-outline',          toggle:false                                },
              { label:'Payment Methods',     icon:'card-outline',          toggle:false                                },
              { label:'Help & Support',      icon:'help-circle-outline',   toggle:false                                },
            ].map((row, idx, arr) => (
              <View key={row.label}>
                <View style={{ flexDirection:'row', alignItems:'center', paddingHorizontal:T.sp.md, paddingVertical:14 }}>
                  <Ionicons name={row.icon} size={20} color={T.gold} style={{ marginRight:T.sp.md }} />
                  <Text style={{ flex:1, color:T.cream, fontSize:T.font.body, fontWeight:'500' }}>{row.label}</Text>
                  {row.toggle
                    ? <Switch value={row.value} onValueChange={row.onChange} trackColor={{false:T.muted,true:T.gold+'66'}} thumbColor={row.value?T.gold:T.ghost} />
                    : <Ionicons name="chevron-forward" size={16} color={T.ghost} />
                  }
                </View>
                {idx < arr.length-1 && <Divider style={{ marginLeft:52 }} />}
              </View>
            ))}
          </Card>
        </Reveal>

        <Reveal delay={330}>
          <GoldButton label="Sign Out" onPress={onLogout} variant="outline" icon="log-out-outline" />
        </Reveal>
      </ScrollView>
    </SafeAreaView>
  );
}

// ═══════════════════════════════════════════════════════════════
// MANAGER APP
// ═══════════════════════════════════════════════════════════════
function ManagerApp({ name, onLogout }) {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown:false,
        tabBarStyle:{ backgroundColor:T.surface, borderTopWidth:1, borderTopColor:T.border, height:80, paddingBottom:20, paddingTop:10 },
        tabBarActiveTintColor:T.success,
        tabBarInactiveTintColor:T.ghost,
        tabBarLabelStyle:{ fontSize:10, fontWeight:'700', letterSpacing:0.5 },
        tabBarIcon:({ focused, color }) => {
          const icons = { Dashboard:focused?'grid':'grid-outline', Orders:focused?'clipboard':'clipboard-outline', 'Manage Menu':focused?'restaurant':'restaurant-outline', Reservations:focused?'calendar':'calendar-outline' };
          return <Ionicons name={icons[route.name]||'ellipse'} size={22} color={color} />;
        },
      })}
    >
      <Tab.Screen name="Dashboard">{p    => <ManagerDashboard  {...p} name={name} onLogout={onLogout} />}</Tab.Screen>
      <Tab.Screen name="Orders"           component={ManagerOrders}       />
      <Tab.Screen name="Manage Menu"      component={ManagerMenu}         />
      <Tab.Screen name="Reservations"     component={ManagerReservations} />
    </Tab.Navigator>
  );
}

// ═══════════════════════════════════════════════════════════════
// MANAGER DASHBOARD
// ═══════════════════════════════════════════════════════════════
function ManagerDashboard({ name, onLogout }) {
  const [g] = useGlobal();
  const active  = g.orders.filter(o => o.status !== 'picked up').length;
  const revenue = g.orders.reduce((s, o) => s + o.total, 0);
  const stats = [
    { label:'Active Orders', value:active,                  icon:'flame',      color:T.danger  },
    { label:'Revenue',       value:`$${revenue.toFixed(0)}`,icon:'trending-up',color:T.success },
    { label:'Reservations',  value:g.reservations.length,   icon:'calendar',   color:T.gold    },
    { label:'Menu Items',    value:g.menuItems.length,      icon:'restaurant', color:T.info    },
  ];
  return (
    <SafeAreaView style={{ flex:1, backgroundColor:T.obsidian }}>
      <View style={{ paddingHorizontal:T.sp.lg, paddingTop:T.sp.lg, flexDirection:'row', justifyContent:'space-between', alignItems:'center', marginBottom:T.sp.lg }}>
        <View>
          <Text style={{ color:T.ghost, fontSize:T.font.caption, letterSpacing:1 }}>Management</Text>
          <Text style={{ color:T.cream, fontSize:T.font.heading, fontWeight:'800' }}>Dashboard</Text>
        </View>
        <View style={{ flexDirection:'row', alignItems:'center' }}>
          <View style={{ paddingHorizontal:12, paddingVertical:6, backgroundColor:T.success+'18', borderRadius:T.r.full, borderWidth:1, borderColor:T.success+'44', flexDirection:'row', alignItems:'center', marginRight:12 }}>
            <View style={{ width:6, height:6, borderRadius:3, backgroundColor:T.success, marginRight:5 }} />
            <Text style={{ color:T.success, fontSize:12, fontWeight:'700' }}>Live</Text>
          </View>
          <TouchableOpacity onPress={onLogout}><Ionicons name="log-out-outline" size={22} color={T.ghost} /></TouchableOpacity>
        </View>
      </View>
      <ScrollView contentContainerStyle={{ paddingHorizontal:T.sp.lg, paddingBottom:40 }} showsVerticalScrollIndicator={false}>
        <Reveal>
          <View style={{ flexDirection:'row', flexWrap:'wrap', marginBottom:T.sp.xl }}>
            {stats.map((s, i) => (
              <View key={s.label} style={{ width:(SW-T.sp.lg*2-T.sp.sm)/2, marginLeft:i%2===1?T.sp.sm:0, marginBottom:T.sp.sm }}>
                <Card style={{ padding:T.sp.md }}>
                  <View style={{ width:40, height:40, borderRadius:T.r.sm, backgroundColor:s.color+'18', alignItems:'center', justifyContent:'center', marginBottom:T.sp.sm }}>
                    <Ionicons name={s.icon} size={20} color={s.color} />
                  </View>
                  <Text style={{ color:T.cream, fontSize:T.font.heading, fontWeight:'900' }}>{s.value}</Text>
                  <Text style={{ color:T.ghost, fontSize:12, marginTop:2 }}>{s.label}</Text>
                </Card>
              </View>
            ))}
          </View>
        </Reveal>
        <Reveal delay={150}>
          <Text style={{ color:T.cream, fontSize:T.font.title, fontWeight:'800', marginBottom:T.sp.md }}>Live Orders</Text>
          {g.orders.slice(0,4).map(order => (
            <Card key={order.id} style={{ marginBottom:T.sp.sm }}>
              <View style={{ padding:T.sp.md }}>
                <View style={{ flexDirection:'row', justifyContent:'space-between', marginBottom:4 }}>
                  <Text style={{ color:T.cream, fontSize:14, fontWeight:'700' }}>{order.id}</Text>
                  <OrderStatusBadge status={order.status} />
                </View>
                <Text style={{ color:T.ghost, fontSize:12 }}>{order.customer} · {order.table} · {order.time}</Text>
                <Text style={{ color:T.gold, fontSize:13, fontWeight:'700', marginTop:4 }}>${order.total.toFixed(2)}</Text>
              </View>
            </Card>
          ))}
        </Reveal>
      </ScrollView>
    </SafeAreaView>
  );
}

// ═══════════════════════════════════════════════════════════════
// MANAGER ORDERS
// ═══════════════════════════════════════════════════════════════
function ManagerOrders() {
  const [g, upd] = useGlobal();
  const [filter, setFilter] = useState('all');
  const NEXT  = { received:'preparing', preparing:'ready', ready:'picked up' };
  const LABEL = { received:'Start Prep', preparing:'Mark Ready', ready:'Picked Up' };
  const advance = (id) => upd(s => ({ orders:s.orders.map(o => o.id===id && NEXT[o.status] ? {...o,status:NEXT[o.status]} : o) }));
  const filtered = filter==='all' ? g.orders : g.orders.filter(o => o.status===filter);

  return (
    <SafeAreaView style={{ flex:1, backgroundColor:T.obsidian }}>
      <Header title="Orders" subtitle="Live Kitchen" />
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ maxHeight:44, marginBottom:T.sp.sm }} contentContainerStyle={{ paddingHorizontal:T.sp.lg }}>
        {['all','received','preparing','ready','picked up'].map((f,i) => (
          <TouchableOpacity key={f} onPress={() => setFilter(f)} style={{ paddingHorizontal:14, paddingVertical:8, borderRadius:T.r.full, borderWidth:1, borderColor:filter===f?T.success:T.border, backgroundColor:filter===f?T.success+'18':T.elevated, marginLeft:i>0?T.sp.sm:0 }}>
            <Text style={{ color:filter===f?T.success:T.ghost, fontSize:12, fontWeight:'700', textTransform:'capitalize' }}>{f}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
      <FlatList
        data={filtered}
        keyExtractor={o => o.id}
        contentContainerStyle={{ paddingHorizontal:T.sp.lg, paddingBottom:20 }}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={<View style={{ alignItems:'center', paddingVertical:60 }}><Text style={{ fontSize:40, marginBottom:12 }}>📋</Text><Text style={{ color:T.ghost, fontSize:T.font.body }}>No orders for this filter</Text></View>}
        renderItem={({ item, index }) => (
          <Reveal delay={index*50}>
            <Card style={{ marginBottom:T.sp.sm }}>
              <View style={{ padding:T.sp.md }}>
                <View style={{ flexDirection:'row', justifyContent:'space-between', alignItems:'center', marginBottom:8 }}>
                  <View>
                    <Text style={{ color:T.cream, fontSize:15, fontWeight:'800' }}>{item.id}</Text>
                    <Text style={{ color:T.ghost, fontSize:12, marginTop:2 }}>{item.customer} · {item.table}</Text>
                  </View>
                  <View style={{ alignItems:'flex-end' }}>
                    <OrderStatusBadge status={item.status} />
                    <Text style={{ color:T.ghost, fontSize:11, marginTop:4 }}>{item.time}</Text>
                  </View>
                </View>
                <View style={{ backgroundColor:T.surface, borderRadius:T.r.sm, padding:T.sp.sm, marginBottom:T.sp.sm }}>
                  {item.items.map((it,idx) => <Text key={idx} style={{ color:T.silver, fontSize:13, marginBottom:2 }}>{it.qty}× {it.name} — ${(it.qty*it.price).toFixed(2)}</Text>)}
                </View>
                {item.notes
                  ? <View style={{ flexDirection:'row', alignItems:'flex-start', backgroundColor:T.warning+'11', borderRadius:T.r.sm, padding:T.sp.sm, marginBottom:T.sp.sm }}>
                      <Ionicons name="warning-outline" size={14} color={T.warning} style={{ marginRight:5, marginTop:1 }} />
                      <Text style={{ color:T.warning, fontSize:12, flex:1 }}>{item.notes}</Text>
                    </View>
                  : null
                }
                <View style={{ flexDirection:'row', justifyContent:'space-between', alignItems:'center' }}>
                  <Text style={{ color:T.gold, fontSize:15, fontWeight:'900' }}>${item.total.toFixed(2)}</Text>
                  {NEXT[item.status]
                    ? <TouchableOpacity onPress={() => advance(item.id)} style={{ paddingHorizontal:16, paddingVertical:8, backgroundColor:T.success, borderRadius:T.r.full }}>
                        <Text style={{ color:T.obsidian, fontSize:12, fontWeight:'800' }}>{LABEL[item.status]}</Text>
                      </TouchableOpacity>
                    : null
                  }
                </View>
              </View>
            </Card>
          </Reveal>
        )}
      />
    </SafeAreaView>
  );
}

// ═══════════════════════════════════════════════════════════════
// MANAGER MENU
// ═══════════════════════════════════════════════════════════════
function ManagerMenu() {
  const [g, upd]  = useGlobal();
  const [showAdd, setShowAdd] = useState(false);
  const EMOJIS = ['🍽️','🥩','🦞','🍄','🐟','🥗','🍫','🧀','🥂','🍕','🍝','🍮','🥘','🦐','🫕'];
  const BLANK  = { name:'', price:'', category:'mains', description:'', emoji:'🍽️' };
  const [form, setForm] = useState(BLANK);

  const deleteItem = (id) => Alert.alert('Delete','Remove this item from the menu?',[
    { text:'Cancel', style:'cancel' },
    { text:'Delete', style:'destructive', onPress:() => upd(s => ({ menuItems:s.menuItems.filter(i => i.id !== id) })) },
  ]);

  const addItem = () => {
    if (!form.name.trim() || !form.price) { Alert.alert('Required','Name and price are required.'); return; }
    const parsed = parseFloat(form.price);
    if (isNaN(parsed) || parsed <= 0)     { Alert.alert('Invalid Price','Please enter a valid positive price.'); return; }
    upd(s => ({
      menuItems:[...s.menuItems,{
        ...form,
        id:Date.now().toString(), price:parsed, subtitle:form.category,
        rating:4.5, reviews:0, calories:0, prepTime:15,
        allergens:[], tags:['New'], available:true,
      }],
    }));
    setShowAdd(false);
    setForm(BLANK);
    Alert.alert('✦ Added','New item published to the menu!');
  };

  return (
    <SafeAreaView style={{ flex:1, backgroundColor:T.obsidian }}>
      <Header title="Menu" subtitle="Manage" rightAction={{ icon:'add-circle-outline', onPress:() => setShowAdd(true) }} />
      <FlatList
        data={g.menuItems}
        keyExtractor={item => item.id}
        contentContainerStyle={{ paddingHorizontal:T.sp.lg, paddingBottom:20 }}
        showsVerticalScrollIndicator={false}
        renderItem={({ item, index }) => (
          <Reveal delay={index*40}>
            <Card style={{ marginBottom:T.sp.sm }}>
              <View style={{ flexDirection:'row', alignItems:'center', padding:T.sp.md }}>
                <View style={{ width:50, height:50, borderRadius:T.r.md, backgroundColor:T.surface, alignItems:'center', justifyContent:'center', marginRight:T.sp.md }}>
                  <Text style={{ fontSize:26 }}>{item.emoji}</Text>
                </View>
                <View style={{ flex:1 }}>
                  <Text style={{ color:T.cream, fontSize:14, fontWeight:'700' }}>{item.name}</Text>
                  <Text style={{ color:T.ghost, fontSize:12, textTransform:'capitalize', marginTop:2 }}>{item.category}</Text>
                </View>
                <Text style={{ color:T.gold, fontSize:15, fontWeight:'800', marginRight:T.sp.md }}>${item.price.toFixed(2)}</Text>
                <TouchableOpacity onPress={() => deleteItem(item.id)}>
                  <Ionicons name="trash-outline" size={20} color={T.danger+'AA'} />
                </TouchableOpacity>
              </View>
            </Card>
          </Reveal>
        )}
      />
      <Sheet visible={showAdd} onClose={() => { setShowAdd(false); setForm(BLANK); }} title="Add Menu Item">
        <ScrollView contentContainerStyle={{ paddingHorizontal:T.sp.lg, paddingBottom:T.sp.md }} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
          <View style={{ marginBottom:T.sp.md }}>
            <Text style={{ color:T.gold, fontSize:T.font.micro, fontWeight:'700', letterSpacing:2, textTransform:'uppercase', marginBottom:10 }}>Icon</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              {EMOJIS.map((e, i) => (
                <TouchableOpacity key={i} onPress={() => setForm(f => ({...f,emoji:e}))} style={{ width:44, height:44, borderRadius:T.r.sm, backgroundColor:form.emoji===e?T.gold+'22':T.surface, borderWidth:1, borderColor:form.emoji===e?T.gold:T.border, alignItems:'center', justifyContent:'center', marginRight:8 }}>
                  <Text style={{ fontSize:22 }}>{e}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
          <LuxInput label="Item Name"   icon="restaurant-outline"    placeholder="e.g. Truffle Pasta" value={form.name}        onChangeText={t => setForm(f=>({...f,name:t}))} />
          <LuxInput label="Price ($)"   icon="pricetag-outline"      placeholder="0.00"               value={form.price}       onChangeText={t => setForm(f=>({...f,price:t}))} keyboardType="decimal-pad" />
          <LuxInput label="Description" icon="document-text-outline"  placeholder="Brief description"  value={form.description} onChangeText={t => setForm(f=>({...f,description:t}))} />
          <View style={{ marginBottom:T.sp.lg }}>
            <Text style={{ color:T.gold, fontSize:T.font.micro, fontWeight:'700', letterSpacing:2, textTransform:'uppercase', marginBottom:10 }}>Category</Text>
            <View style={{ flexDirection:'row', flexWrap:'wrap' }}>
              {['starters','mains','signature','desserts','wines'].map((cat,i) => (
                <TouchableOpacity key={cat} onPress={() => setForm(f=>({...f,category:cat}))} style={{ paddingHorizontal:14, paddingVertical:8, borderRadius:T.r.full, borderWidth:1, borderColor:form.category===cat?T.gold:T.border, backgroundColor:form.category===cat?T.gold+'18':T.surface, marginRight:T.sp.sm, marginBottom:T.sp.sm }}>
                  <Text style={{ color:form.category===cat?T.gold:T.ghost, fontSize:13, textTransform:'capitalize' }}>{cat}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
          <GoldButton label="Add to Menu" onPress={addItem} icon="add-circle-outline" style={{ marginBottom:T.sp.lg }} />
        </ScrollView>
      </Sheet>
    </SafeAreaView>
  );
}

// ═══════════════════════════════════════════════════════════════
// MANAGER RESERVATIONS
// ═══════════════════════════════════════════════════════════════
function ManagerReservations() {
  const [g, upd] = useGlobal();
  const setStatus = (id, status) => upd(s => ({ reservations:s.reservations.map(r => r.id===id ? {...r,status} : r) }));

  return (
    <SafeAreaView style={{ flex:1, backgroundColor:T.obsidian }}>
      <Header title="Reservations" subtitle="Table Management" />
      <FlatList
        data={g.reservations}
        keyExtractor={r => r.id}
        contentContainerStyle={{ paddingHorizontal:T.sp.lg, paddingBottom:20 }}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={{ alignItems:'center', paddingVertical:80 }}>
            <Text style={{ fontSize:48, marginBottom:16 }}>🗓️</Text>
            <Text style={{ color:T.cream, fontSize:T.font.title, fontWeight:'700', marginBottom:8 }}>No reservations yet</Text>
            <Text style={{ color:T.ghost, fontSize:T.font.body, textAlign:'center' }}>Customer bookings will appear here</Text>
          </View>
        }
        renderItem={({ item, index }) => (
          <Reveal delay={index*60}>
            <Card style={{ marginBottom:T.sp.sm }}>
              <View style={{ padding:T.sp.md }}>
                <View style={{ flexDirection:'row', justifyContent:'space-between', alignItems:'flex-start', marginBottom:8 }}>
                  <View>
                    <Text style={{ color:T.cream, fontSize:15, fontWeight:'800' }}>{item.name}</Text>
                    <Text style={{ color:T.ghost, fontSize:12, marginTop:2 }}>{item.id}</Text>
                  </View>
                  <View style={{ paddingHorizontal:10, paddingVertical:3, borderRadius:T.r.full, backgroundColor:item.status==='confirmed'?T.success+'22':item.status==='cancelled'?T.danger+'22':T.warning+'22' }}>
                    <Text style={{ color:item.status==='confirmed'?T.success:item.status==='cancelled'?T.danger:T.warning, fontSize:11, fontWeight:'700', textTransform:'uppercase' }}>{item.status}</Text>
                  </View>
                </View>
                <View style={{ flexDirection:'row', marginBottom:8 }}>
                  {[{icon:'calendar-outline',val:item.date},{icon:'time-outline',val:item.time},{icon:'people-outline',val:`${item.partySize}`}].map((row,i) => (
                    <View key={i} style={{ flexDirection:'row', alignItems:'center', marginRight:T.sp.md }}>
                      <Ionicons name={row.icon} size={14} color={T.ghost} style={{ marginRight:4 }} />
                      <Text style={{ color:T.silver, fontSize:13 }}>{row.val}</Text>
                    </View>
                  ))}
                </View>
                {item.occasion ? <View style={{ flexDirection:'row', alignItems:'center', marginBottom:8 }}><Ionicons name="gift-outline" size={14} color={T.gold} style={{ marginRight:5 }} /><Text style={{ color:T.gold, fontSize:13 }}>{item.occasion}</Text></View> : null}
                <Text style={{ color:T.ghost, fontSize:12, marginBottom:item.status==='pending'?12:0 }}>{item.phone}</Text>
                {item.status === 'pending'
                  ? <View style={{ flexDirection:'row' }}>
                      <TouchableOpacity onPress={() => setStatus(item.id,'confirmed')} style={{ flex:1, paddingVertical:10, borderRadius:T.r.md, backgroundColor:T.success, alignItems:'center', marginRight:T.sp.sm }}>
                        <Text style={{ color:T.obsidian, fontSize:13, fontWeight:'800' }}>Confirm</Text>
                      </TouchableOpacity>
                      <TouchableOpacity onPress={() => setStatus(item.id,'cancelled')} style={{ flex:1, paddingVertical:10, borderRadius:T.r.md, backgroundColor:T.danger+'22', borderWidth:1, borderColor:T.danger+'55', alignItems:'center' }}>
                        <Text style={{ color:T.danger, fontSize:13, fontWeight:'800' }}>Decline</Text>
                      </TouchableOpacity>
                    </View>
                  : null
                }
              </View>
            </Card>
          </Reveal>
        )}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({});