/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║           LUMIÈRE — Premium Restaurant Experience            ║
 * ║         The World's Most Beautiful Restaurant App            ║
 * ║                    ✦ Expo Snack Ready ✦                      ║
 * ╚══════════════════════════════════════════════════════════════╝
 * 
 * Features:
 * • Stunning dark luxury design with gold accents
 * • Beautiful food imagery with placeholder images
 * • Smooth scrolling on all screens
 * • Complete auth flow (customer/manager)
 * • Real cart, reservations, and order management
 * • Loyalty points system
 * • Fully responsive for all device sizes
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  SafeAreaView,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  FlatList,
  Alert,
  Modal,
  StatusBar,
  Animated,
  Dimensions,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
  Switch,
  Image,
} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';

const { width: SW, height: SH } = Dimensions.get('window');
const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

// ═══════════════════════════════════════════════════════════════
// DESIGN TOKENS — Dark Luxury Editorial
// ═══════════════════════════════════════════════════════════════
const T = {
  obsidian: '#0A0A0F',
  surface: '#16161F',
  elevated: '#1E1E2A',
  border: '#2A2A3A',
  muted: '#3A3A50',
  gold: '#C9A96E',
  goldLight: '#E8C98A',
  goldDim: '#8B7040',
  cream: '#F5F0E8',
  silver: '#A8A8B8',
  ghost: '#6B6B80',
  success: '#4ECDA4',
  warning: '#F59E0B',
  danger: '#EF4444',
  info: '#60A5FA',
  font: { hero: 36, heading: 24, title: 20, body: 16, caption: 13, micro: 11 },
  sp: { xs: 4, sm: 8, md: 16, lg: 24, xl: 32, xxl: 48 },
  r: { sm: 6, md: 12, lg: 20, xl: 28, full: 999 },
};

// ═══════════════════════════════════════════════════════════════
// IMAGE PLACEHOLDERS — Using Unsplash for beautiful food imagery
// ═══════════════════════════════════════════════════════════════
const IMAGES = {
  // Food images
  wagyu: 'https://images.unsplash.com/photo-1600891964092-4316c288032e?w=400',
  lobster: 'https://images.unsplash.com/photo-1625943553852-781c6dd46faa?w=400',
  truffle: 'https://images.unsplash.com/photo-1639024471283-03518883512d?w=400',
  foie: 'https://images.unsplash.com/photo-1476224203421-9ac39bcb332e?w=400',
  bouillabaisse: 'https://images.unsplash.com/photo-1559339352-11d035aa65de?w=400',
  souffle: 'https://images.unsplash.com/photo-1541783245831-57d6fb0926d3?w=400',
  champagne: 'https://images.unsplash.com/photo-1569523515814-4bdc7a1c93b2?w=400',
  burrata: 'https://images.unsplash.com/photo-1623428187969-5da2dcea5ebf?w=400',
  
  // Restaurant ambiance
  restaurant: 'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=800',
  chef: 'https://images.unsplash.com/photo-1577219491135-ce391730fb2c?w=800',
  interior: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800',
  
  // Default fallback
  default: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=400',
};

// ═══════════════════════════════════════════════════════════════
// DATA
// ═══════════════════════════════════════════════════════════════
const TIME_SLOTS = ['5:30 PM', '6:00 PM', '6:30 PM', '7:00 PM', '7:30 PM', '8:00 PM', '8:30 PM', '9:00 PM'];

const INITIAL_MENU = [
  { id: '1', name: 'Wagyu Beef Tenderloin', subtitle: 'A5 Grade · 45-day dry aged', price: 89, category: 'signature', emoji: '🥩', image: IMAGES.wagyu, tags: ["Chef's Pick", 'Bestseller'], description: 'Japanese A5 Wagyu, black truffle butter, pommes purée.', rating: 4.9, reviews: 284, calories: 620, prepTime: 25, allergens: ['dairy'], available: true },
  { id: '2', name: 'Lobster Bisque', subtitle: 'Maine Lobster · Cognac Cream', price: 32, category: 'starters', emoji: '🦞', image: IMAGES.lobster, tags: ['Seasonal'], description: 'Velvety Maine lobster bisque, cognac, crème fraîche.', rating: 4.8, reviews: 198, calories: 340, prepTime: 15, allergens: ['shellfish', 'dairy'], available: true },
  { id: '3', name: 'Black Truffle Risotto', subtitle: 'Arborio · Parmigiano 36M', price: 42, category: 'mains', emoji: '🍄', image: IMAGES.truffle, tags: ['Vegetarian'], description: 'Carnaroli risotto, Périgord black truffle, aged Parmigiano.', rating: 4.7, reviews: 156, calories: 480, prepTime: 20, allergens: ['dairy', 'gluten'], available: true },
  { id: '4', name: 'Seared Foie Gras', subtitle: 'Brioche · Sauternes Gelée', price: 38, category: 'starters', emoji: '🪭', image: IMAGES.foie, tags: ['Luxury'], description: 'Pan-seared foie gras, brioche, quince compote, Sauternes.', rating: 4.6, reviews: 112, calories: 520, prepTime: 12, allergens: ['gluten', 'dairy'], available: true },
  { id: '5', name: 'Bouillabaisse Royale', subtitle: 'Provence · Rouille · Gruyère', price: 54, category: 'mains', emoji: '🐟', image: IMAGES.bouillabaisse, tags: ['Signature'], description: 'Provençal fish stew, saffron broth, rouille croutons.', rating: 4.8, reviews: 203, calories: 580, prepTime: 30, allergens: ['fish', 'shellfish', 'gluten'], available: true },
  { id: '6', name: 'Valrhona Soufflé', subtitle: '72% Dark Chocolate', price: 22, category: 'desserts', emoji: '🍫', image: IMAGES.souffle, tags: ['Must Order'], description: 'Chocolate soufflé, Tahitian vanilla crème anglaise.', rating: 4.9, reviews: 341, calories: 380, prepTime: 12, allergens: ['eggs', 'dairy', 'gluten'], available: true },
  { id: '7', name: 'Champagne Dom Pérignon', subtitle: 'Vintage 2013 · Épernay', price: 320, category: 'wines', emoji: '🥂', image: IMAGES.champagne, tags: ['Iconic'], description: 'Prestige cuvée. Almond, citrus, chalky minerality.', rating: 5.0, reviews: 89, calories: 0, prepTime: 0, allergens: [], available: true },
  { id: '8', name: 'Burrata & Heirloom', subtitle: 'Stracciatella · Basil Oil', price: 24, category: 'starters', emoji: '🧀', image: IMAGES.burrata, tags: ['Vegetarian', 'Fresh'], description: 'Hand-stretched burrata, heirloom tomatoes, aged balsamic.', rating: 4.7, reviews: 178, calories: 290, prepTime: 8, allergens: ['dairy'], available: true },
];

const FEATURED = INITIAL_MENU.slice(0, 3);

const CATEGORIES = [
  { id: 'all', name: 'All', icon: '✦' },
  { id: 'starters', name: 'Starters', icon: '🌿' },
  { id: 'mains', name: 'Mains', icon: '🍽️' },
  { id: 'signature', name: 'Signature', icon: '⭐' },
  { id: 'desserts', name: 'Desserts', icon: '🍮' },
  { id: 'wines', name: 'Wines', icon: '🍷' },
];

const DEMO_ORDERS = [
  { id: 'ORD-2847', customer: 'Alexandra Chen', table: 'Table 12', items: [{ name: 'Wagyu Beef Tenderloin', qty: 2, price: 89 }, { name: 'Lobster Bisque', qty: 1, price: 32 }, { name: 'Valrhona Soufflé', qty: 2, price: 22 }], total: 254, status: 'preparing', time: '8:15 PM', notes: 'Allergy: shellfish for guest 2', priority: 'high' },
  { id: 'ORD-2846', customer: 'Marcus Wellington', table: 'Bar Seat 3', items: [{ name: 'Seared Foie Gras', qty: 1, price: 38 }, { name: 'Champagne Dom Pérignon', qty: 1, price: 320 }], total: 358, status: 'ready', time: '8:00 PM', notes: '', priority: 'normal' },
  { id: 'ORD-2845', customer: 'Sofia Reyes', table: 'Private Room', items: [{ name: 'Black Truffle Risotto', qty: 3, price: 42 }, { name: 'Burrata & Heirloom', qty: 2, price: 24 }], total: 174, status: 'received', time: '7:45 PM', notes: 'Birthday — cake at 9pm', priority: 'normal' },
];

// ═══════════════════════════════════════════════════════════════
// GLOBAL STATE
// ═══════════════════════════════════════════════════════════════
let G = {
  cart: [],
  loyalty: 1240,
  reservations: [],
  menuItems: [...INITIAL_MENU],
  orders: DEMO_ORDERS,
};
const _subs = new Set();

function updateG(fn) {
  G = { ...G, ...fn(G) };
  _subs.forEach(cb => cb(G));
}

function useGlobal() {
  const [s, setS] = useState(G);
  useEffect(() => {
    _subs.add(setS);
    return () => _subs.delete(setS);
  }, []);
  return [s, updateG];
}

// Polyfill findLastIndex
function lastIndexOf(arr, pred) {
  for (let i = arr.length - 1; i >= 0; i--) {
    if (pred(arr[i])) return i;
  }
  return -1;
}

// ═══════════════════════════════════════════════════════════════
// ANIMATED COMPONENTS
// ═══════════════════════════════════════════════════════════════
function FadeIn({ children, delay = 0, style }) {
  const opacity = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.timing(opacity, {
      toValue: 1,
      duration: 600,
      delay,
      useNativeDriver: true,
    }).start();
  }, []);
  return <Animated.View style={[{ opacity }, style]}>{children}</Animated.View>;
}

function SlideUp({ children, delay = 0, style }) {
  const translateY = useRef(new Animated.Value(30)).current;
  const opacity = useRef(new Animated.Value(0)).current;
  
  useEffect(() => {
    Animated.parallel([
      Animated.timing(translateY, {
        toValue: 0,
        duration: 500,
        delay,
        useNativeDriver: true,
      }),
      Animated.timing(opacity, {
        toValue: 1,
        duration: 500,
        delay,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);
  
  return (
    <Animated.View style={[{ opacity, transform: [{ translateY }] }, style]}>
      {children}
    </Animated.View>
  );
}

function ScaleIn({ children, delay = 0, style }) {
  const scale = useRef(new Animated.Value(0.9)).current;
  const opacity = useRef(new Animated.Value(0)).current;
  
  useEffect(() => {
    Animated.parallel([
      Animated.spring(scale, {
        toValue: 1,
        tension: 50,
        friction: 7,
        delay,
        useNativeDriver: true,
      }),
      Animated.timing(opacity, {
        toValue: 1,
        duration: 400,
        delay,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);
  
  return (
    <Animated.View style={[{ opacity, transform: [{ scale }] }, style]}>
      {children}
    </Animated.View>
  );
}

// ═══════════════════════════════════════════════════════════════
// UI COMPONENTS
// ═══════════════════════════════════════════════════════════════
function Header({ title, subtitle, rightAction, leftAction }) {
  return (
    <View style={styles.header}>
      {leftAction ? (
        <TouchableOpacity onPress={leftAction.onPress} style={styles.headerLeft}>
          <Ionicons name={leftAction.icon || 'chevron-back'} size={24} color={T.cream} />
        </TouchableOpacity>
      ) : <View style={styles.headerPlaceholder} />}
      
      <View style={styles.headerCenter}>
        {subtitle ? <Text style={styles.headerSubtitle}>{subtitle}</Text> : null}
        <Text style={styles.headerTitle}>{title}</Text>
      </View>
      
      {rightAction ? (
        <TouchableOpacity onPress={rightAction.onPress} style={styles.headerRight}>
          <View>
            <Ionicons name={rightAction.icon || 'ellipsis-horizontal'} size={24} color={T.cream} />
            {rightAction.badge > 0 ? (
              <View style={styles.badge}>
                <Text style={styles.badgeText}>{rightAction.badge}</Text>
              </View>
            ) : null}
          </View>
        </TouchableOpacity>
      ) : <View style={styles.headerPlaceholder} />}
    </View>
  );
}

function GoldButton({ label, onPress, loading = false, variant = 'gold', style, icon }) {
  const colors = variant === 'gold' ? [T.gold, T.goldDim] : 
                 variant === 'outline' ? ['transparent', 'transparent'] : 
                 ['#2A2A3A', '#1E1E2A'];
  
  return (
    <TouchableOpacity onPress={onPress} disabled={loading} style={style} activeOpacity={0.82}>
      <LinearGradient
        colors={colors}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={[
          styles.goldButton,
          variant === 'outline' && styles.goldButtonOutline,
        ]}
      >
        {loading ? (
          <ActivityIndicator color={variant === 'gold' ? T.obsidian : T.gold} />
        ) : (
          <>
            {icon ? <Ionicons name={icon} size={18} color={variant === 'gold' ? T.obsidian : T.gold} style={styles.buttonIcon} /> : null}
            <Text style={[styles.goldButtonText, variant === 'outline' && styles.goldButtonTextOutline]}>
              {label}
            </Text>
          </>
        )}
      </LinearGradient>
    </TouchableOpacity>
  );
}

function LuxInput({ label, icon, containerStyle, multiline, ...props }) {
  const [focused, setFocused] = useState(false);
  return (
    <View style={[styles.inputContainer, containerStyle]}>
      {label ? <Text style={styles.inputLabel}>{label}</Text> : null}
      <View style={[styles.inputWrapper, focused && styles.inputWrapperFocused]}>
        {icon ? <Ionicons name={icon} size={18} color={focused ? T.gold : T.ghost} style={styles.inputIcon} /> : null}
        <TextInput
          style={[styles.input, multiline && styles.inputMultiline]}
          placeholderTextColor={T.ghost}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          multiline={multiline}
          {...props}
        />
      </View>
    </View>
  );
}

function Card({ children, style, onPress, glow = false }) {
  const inner = (
    <View style={[styles.card, glow && styles.cardGlow, style]}>
      {children}
    </View>
  );
  
  if (onPress) {
    return <TouchableOpacity onPress={onPress} activeOpacity={0.85}>{inner}</TouchableOpacity>;
  }
  return inner;
}

function Badge({ label, color = T.gold, style }) {
  return (
    <View style={[styles.badgeContainer, { borderColor: color + '55', backgroundColor: color + '22' }, style]}>
      <Text style={[styles.badgeLabel, { color }]}>{label}</Text>
    </View>
  );
}

function Stars({ rating, reviews }) {
  return (
    <View style={styles.starsContainer}>
      <Ionicons name="star" size={12} color={T.gold} />
      <Text style={styles.starsRating}>{rating}</Text>
      <Text style={styles.starsReviews}>({reviews})</Text>
    </View>
  );
}

function LoyaltyBadge({ points }) {
  return (
    <View style={styles.loyaltyBadge}>
      <Ionicons name="diamond" size={14} color={T.gold} />
      <Text style={styles.loyaltyText}>{points.toLocaleString()} pts</Text>
    </View>
  );
}

function OrderStatusBadge({ status }) {
  const MAP = {
    received: { color: T.warning, label: 'Received' },
    preparing: { color: T.info, label: 'Preparing' },
    ready: { color: T.success, label: 'Ready' },
    'picked up': { color: T.ghost, label: 'Done' },
  };
  const c = MAP[status] || MAP.received;
  
  return (
    <View style={[styles.statusBadge, { backgroundColor: c.color + '22', borderColor: c.color + '55' }]}>
      <Text style={[styles.statusText, { color: c.color }]}>{c.label}</Text>
    </View>
  );
}

function Sheet({ visible, onClose, title, children }) {
  const slideY = useRef(new Animated.Value(SH)).current;
  const overlayO = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (visible) {
      Animated.parallel([
        Animated.spring(slideY, { toValue: 0, tension: 65, friction: 11, useNativeDriver: true }),
        Animated.timing(overlayO, { toValue: 1, duration: 220, useNativeDriver: true }),
      ]).start();
    } else {
      Animated.parallel([
        Animated.timing(slideY, { toValue: SH, duration: 260, useNativeDriver: true }),
        Animated.timing(overlayO, { toValue: 0, duration: 200, useNativeDriver: true }),
      ]).start();
    }
  }, [visible]);

  return (
    <Modal visible={visible} transparent animationType="none" onRequestClose={onClose}>
      <View style={StyleSheet.absoluteFill} pointerEvents="box-none">
        <Animated.View style={[StyleSheet.absoluteFill, styles.sheetOverlay, { opacity: overlayO }]}>
          <TouchableOpacity style={styles.sheetOverlayTouch} activeOpacity={1} onPress={onClose} />
        </Animated.View>
      </View>
      <Animated.View style={[styles.sheet, { transform: [{ translateY: slideY }] }]}>
        <View style={styles.sheetHandle}>
          <View style={styles.sheetHandleBar} />
          {title ? <Text style={styles.sheetTitle}>{title}</Text> : null}
        </View>
        <ScrollView showsVerticalScrollIndicator={false} bounces={false}>
          {children}
        </ScrollView>
      </Animated.View>
    </Modal>
  );
}

// ═══════════════════════════════════════════════════════════════
// AUTH SCREEN
// ═══════════════════════════════════════════════════════════════
function AuthScreen({ onLogin }) {
  const [mode, setMode] = useState('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [role, setRole] = useState('customer');
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);

  const submit = () => {
    if (!email.trim() || !password.trim()) {
      Alert.alert('Required', 'Please enter email and password.');
      return;
    }
    if (mode === 'signup' && !name.trim()) {
      Alert.alert('Required', 'Please enter your full name.');
      return;
    }
    
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      if (mode === 'login') {
        const isMgr = email.toLowerCase().includes('manager');
        onLogin(isMgr ? 'manager' : 'customer', isMgr ? 'Manager' : email.split('@')[0]);
      } else {
        onLogin(role, name.trim());
      }
    }, 1100);
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={T.obsidian} />
      
      {/* Background Image with Overlay */}
      <Image source={{ uri: IMAGES.restaurant }} style={styles.authBackground} />
      <LinearGradient
        colors={['rgba(10,10,15,0.95)', T.obsidian]}
        style={StyleSheet.absoluteFill}
      />
      
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={styles.flex1}>
        <ScrollView 
          contentContainerStyle={styles.authScrollContent} 
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
          bounces={false}
        >
          {/* Logo */}
          <FadeIn>
            <View style={styles.logoContainer}>
              <LinearGradient
                colors={[T.gold + '40', T.gold + '10']}
                style={styles.logoGlow}
              >
                <Text style={styles.logoEmoji}>✦</Text>
              </LinearGradient>
              <Text style={styles.logoText}>LUMIÈRE</Text>
              <Text style={styles.logoSubtext}>Fine Dining Experience</Text>
            </View>
          </FadeIn>

          {/* Mode Toggle */}
          <SlideUp delay={150}>
            <View style={styles.modeToggle}>
              {['login', 'signup'].map(m => (
                <TouchableOpacity
                  key={m}
                  onPress={() => setMode(m)}
                  style={[styles.modeButton, mode === m && styles.modeButtonActive]}
                >
                  <Text style={[styles.modeButtonText, mode === m && styles.modeButtonTextActive]}>
                    {m === 'login' ? 'Sign In' : 'Create Account'}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </SlideUp>

          {/* Form */}
          <SlideUp delay={250}>
            <View style={styles.formContainer}>
              {mode === 'signup' && (
                <>
                  <LuxInput
                    label="Full Name"
                    icon="person-outline"
                    placeholder="Your name"
                    value={name}
                    onChangeText={setName}
                    autoCapitalize="words"
                  />
                  <LuxInput
                    label="Phone"
                    icon="call-outline"
                    placeholder="+1 (555) 000-0000"
                    value={phone}
                    onChangeText={setPhone}
                    keyboardType="phone-pad"
                  />
                </>
              )}

              <LuxInput
                label="Email"
                icon="mail-outline"
                placeholder="your@email.com"
                value={email}
                onChangeText={setEmail}
                keyboardType="email-address"
                autoCapitalize="none"
              />

              <View style={styles.passwordContainer}>
                <Text style={styles.inputLabel}>Password</Text>
                <View style={styles.passwordWrapper}>
                  <Ionicons name="lock-closed-outline" size={18} color={T.ghost} style={styles.inputIcon} />
                  <TextInput
                    style={styles.passwordInput}
                    placeholder="••••••••"
                    placeholderTextColor={T.ghost}
                    secureTextEntry={!showPass}
                    value={password}
                    onChangeText={setPassword}
                  />
                  <TouchableOpacity onPress={() => setShowPass(!showPass)}>
                    <Ionicons name={showPass ? 'eye-off-outline' : 'eye-outline'} size={20} color={T.ghost} />
                  </TouchableOpacity>
                </View>
              </View>

              {mode === 'signup' && (
                <View style={styles.roleContainer}>
                  <Text style={styles.inputLabel}>I Am A</Text>
                  <View style={styles.roleButtons}>
                    {[
                      { id: 'customer', label: 'Guest', icon: 'person-outline' },
                      { id: 'manager', label: 'Staff', icon: 'briefcase-outline' },
                    ].map((r, i) => (
                      <TouchableOpacity
                        key={r.id}
                        onPress={() => setRole(r.id)}
                        style={[
                          styles.roleButton,
                          role === r.id && styles.roleButtonActive,
                          i === 1 && styles.roleButtonMargin,
                        ]}
                      >
                        <Ionicons
                          name={r.icon}
                          size={18}
                          color={role === r.id ? T.gold : T.ghost}
                          style={styles.roleIcon}
                        />
                        <Text style={[styles.roleText, role === r.id && styles.roleTextActive]}>
                          {r.label}
                        </Text>
                      </TouchableOpacity>
                    ))}
                  </View>
                </View>
              )}

              <GoldButton
                label={mode === 'login' ? 'Sign In' : 'Create Account'}
                onPress={submit}
                loading={loading}
                style={styles.submitButton}
              />
            </View>
          </SlideUp>

          {/* Demo Hint */}
          <SlideUp delay={420}>
            <LinearGradient
              colors={[T.surface, T.elevated]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={styles.demoCard}
            >
              <Text style={styles.demoTitle}>Demo Access</Text>
              <Text style={styles.demoText}>
                <Text style={styles.demoLabel}>Guest: </Text>guest@lumiere.com{'\n'}
                <Text style={styles.demoLabel}>Manager: </Text>manager@lumiere.com{'\n'}
                <Text style={styles.demoLabel}>Password: </Text>anything works
              </Text>
            </LinearGradient>
          </SlideUp>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

// ═══════════════════════════════════════════════════════════════
// CUSTOMER APP
// ═══════════════════════════════════════════════════════════════
function CustomerApp({ name, onLogout }) {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarStyle: styles.tabBar,
        tabBarActiveTintColor: T.gold,
        tabBarInactiveTintColor: T.ghost,
        tabBarLabelStyle: styles.tabBarLabel,
        tabBarIcon: ({ focused, color }) => {
          const icons = {
            Home: focused ? 'home' : 'home-outline',
            Explore: focused ? 'compass' : 'compass-outline',
            Reserve: focused ? 'calendar' : 'calendar-outline',
            Cart: focused ? 'cart' : 'cart-outline',
            Profile: focused ? 'person' : 'person-outline',
          };
          return <Ionicons name={icons[route.name]} size={22} color={color} />;
        },
      })}
    >
      <Tab.Screen name="Home">{p => <HomeScreen {...p} name={name} onLogout={onLogout} />}</Tab.Screen>
      <Tab.Screen name="Explore" component={ExploreScreen} />
      <Tab.Screen name="Reserve" component={ReservationScreen} />
      <Tab.Screen name="Cart" component={CartScreen} />
      <Tab.Screen name="Profile">{p => <ProfileScreen {...p} name={name} onLogout={onLogout} />}</Tab.Screen>
    </Tab.Navigator>
  );
}

// ═══════════════════════════════════════════════════════════════
// HOME SCREEN
// ═══════════════════════════════════════════════════════════════
function HomeScreen({ name, onLogout }) {
  const [g] = useGlobal();
  const h = new Date().getHours();
  const greet = h < 12 ? 'Good Morning' : h < 17 ? 'Good Afternoon' : 'Good Evening';

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={T.obsidian} />
      
      <ScrollView showsVerticalScrollIndicator={false} bounces={true}>
        {/* Header */}
        <FadeIn>
          <View style={styles.homeHeader}>
            <View>
              <Text style={styles.greeting}>{greet}</Text>
              <Text style={styles.userName}>{name || 'Guest'} ✦</Text>
            </View>
            <View style={styles.headerActions}>
              <LoyaltyBadge points={g.loyalty} />
              <TouchableOpacity onPress={onLogout} style={styles.logoutButton}>
                <Ionicons name="log-out-outline" size={18} color={T.ghost} />
              </TouchableOpacity>
            </View>
          </View>
        </FadeIn>

        {/* Hero Image */}
        <ScaleIn delay={100}>
          <View style={styles.heroContainer}>
            <Image source={{ uri: IMAGES.interior }} style={styles.heroImage} />
            <LinearGradient
              colors={['transparent', T.obsidian]}
              style={styles.heroOverlay}
            >
              <View style={styles.heroContent}>
                <Text style={styles.heroTitle}>Tonight's Specials</Text>
                <Badge label="SEASONAL" color={T.success} />
              </View>
            </LinearGradient>
          </View>
        </ScaleIn>

        {/* Featured Items */}
        <View style={styles.featuredSection}>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.featuredScroll}
            decelerationRate="fast"
          >
            {FEATURED.map((item, i) => (
              <SlideUp key={item.id} delay={150 + i * 100}>
                <FeaturedCard item={item} />
              </SlideUp>
            ))}
          </ScrollView>
        </View>

        {/* Live Stats */}
        <SlideUp delay={250}>
          <View style={styles.statsRow}>
            {[
              { label: 'Tables', value: '4 left', icon: 'people-outline', color: T.success },
              { label: 'Wait', value: '~20 min', icon: 'time-outline', color: T.warning },
              { label: 'Open', value: 'Until 11', icon: 'moon-outline', color: T.info },
            ].map((s, i) => (
              <View key={s.label} style={[styles.statCard, i > 0 && styles.statCardMargin]}>
                <Ionicons name={s.icon} size={20} color={s.color} />
                <Text style={styles.statValue}>{s.value}</Text>
                <Text style={styles.statLabel}>{s.label.toUpperCase()}</Text>
              </View>
            ))}
          </View>
        </SlideUp>

        {/* Quick Actions */}
        <SlideUp delay={320}>
          <View style={styles.quickActions}>
            <Text style={styles.sectionTitle}>Quick Actions</Text>
            <View style={styles.actionButtons}>
              {[
                { label: 'Reserve Table', icon: 'calendar', colors: [T.gold, '#A07830'] },
                { label: 'Order Now', icon: 'restaurant', colors: ['#4ECDA4', '#35A080'] },
              ].map((a, i) => (
                <TouchableOpacity key={a.label} style={[styles.actionButton, i > 0 && styles.actionButtonMargin]}>
                  <LinearGradient colors={a.colors} style={styles.actionGradient}>
                    <Ionicons name={a.icon} size={28} color="rgba(0,0,0,0.55)" />
                    <Text style={styles.actionLabel}>{a.label}</Text>
                  </LinearGradient>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        </SlideUp>

        {/* Most Loved */}
        <SlideUp delay={400}>
          <View style={styles.mostLovedSection}>
            <Text style={styles.sectionTitle}>Most Loved</Text>
            {g.menuItems.slice(0, 5).map((item, i) => (
              <CompactMenuItem key={item.id} item={item} delay={i * 60} />
            ))}
          </View>
        </SlideUp>
        
        <View style={styles.bottomSpacer} />
      </ScrollView>
    </View>
  );
}

function FeaturedCard({ item }) {
  const scale = useRef(new Animated.Value(1)).current;
  const [added, setAdded] = useState(false);
  
  const add = () => {
    updateG(s => ({
      cart: [...s.cart, { ...item, cartId: Date.now() }],
      loyalty: s.loyalty + Math.floor(item.price),
    }));
    setAdded(true);
    Animated.sequence([
      Animated.timing(scale, { toValue: 0.93, duration: 80, useNativeDriver: true }),
      Animated.spring(scale, { toValue: 1, tension: 200, friction: 7, useNativeDriver: true }),
    ]).start();
  };
  
  return (
    <Animated.View style={[styles.featuredCard, { transform: [{ scale }] }]}>
      <Card glow>
        <Image source={{ uri: item.image }} style={styles.featuredImage} />
        <LinearGradient
          colors={['transparent', 'rgba(0,0,0,0.8)']}
          style={styles.featuredGradient}
        >
          <View style={styles.featuredContent}>
            <View style={styles.featuredHeader}>
              <Text style={styles.featuredEmoji}>{item.emoji}</Text>
              <View style={styles.featuredTags}>
                {item.tags.slice(0, 2).map(t => (
                  <Badge key={t} label={t} style={styles.featuredTag} />
                ))}
              </View>
            </View>
            <Text style={styles.featuredName}>{item.name}</Text>
            <Text style={styles.featuredSubtitle}>{item.subtitle}</Text>
            <Stars rating={item.rating} reviews={item.reviews} />
            <View style={styles.featuredFooter}>
              <Text style={styles.featuredPrice}>${item.price.toFixed(2)}</Text>
              <TouchableOpacity onPress={add} style={styles.featuredAddButton}>
                <Ionicons name={added ? 'checkmark' : 'add'} size={20} color={added ? T.success : T.gold} />
              </TouchableOpacity>
            </View>
          </View>
        </LinearGradient>
      </Card>
    </Animated.View>
  );
}

function CompactMenuItem({ item, delay }) {
  const [qty, setQty] = useState(0);
  
  const add = () => {
    setQty(q => q + 1);
    updateG(s => ({
      cart: [...s.cart, { ...item, cartId: Date.now() }],
      loyalty: s.loyalty + Math.floor(item.price),
    }));
  };
  
  const rem = () => {
    if (qty === 0) return;
    setQty(q => q - 1);
    updateG(s => {
      const cart = [...s.cart];
      const idx = lastIndexOf(cart, c => c.id === item.id);
      if (idx !== -1) cart.splice(idx, 1);
      return { cart };
    });
  };
  
  return (
    <SlideUp delay={delay}>
      <Card style={styles.compactCard}>
        <View style={styles.compactContent}>
          <Image source={{ uri: item.image }} style={styles.compactImage} />
          <View style={styles.compactInfo}>
            <Text style={styles.compactName}>{item.name}</Text>
            <Stars rating={item.rating} reviews={item.reviews} />
          </View>
          <View style={styles.compactActions}>
            <Text style={styles.compactPrice}>${item.price.toFixed(2)}</Text>
            {qty === 0 ? (
              <TouchableOpacity onPress={add} style={styles.compactAddButton}>
                <Text style={styles.compactAddText}>ADD</Text>
              </TouchableOpacity>
            ) : (
              <View style={styles.quantityControls}>
                <TouchableOpacity onPress={rem}>
                  <Ionicons name="remove-circle" size={26} color={T.gold} />
                </TouchableOpacity>
                <Text style={styles.quantityText}>{qty}</Text>
                <TouchableOpacity onPress={add}>
                  <Ionicons name="add-circle" size={26} color={T.gold} />
                </TouchableOpacity>
              </View>
            )}
          </View>
        </View>
      </Card>
    </SlideUp>
  );
}

// ═══════════════════════════════════════════════════════════════
// EXPLORE SCREEN
// ═══════════════════════════════════════════════════════════════
function ExploreScreen() {
  const [g] = useGlobal();
  const [cat, setCat] = useState('all');
  const [search, setSearch] = useState('');
  const [detail, setDetail] = useState(null);

  const filtered = g.menuItems.filter(item => {
    const okCat = cat === 'all' || item.category === cat;
    const okSearch = !search || item.name.toLowerCase().includes(search.toLowerCase());
    return okCat && okSearch;
  });

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={T.obsidian} />
      
      <Header title="Menu" subtitle="Lumière" />
      
      <View style={styles.searchContainer}>
        <View style={styles.searchBar}>
          <Ionicons name="search-outline" size={18} color={T.ghost} style={styles.searchIcon} />
          <TextInput
            style={styles.searchInput}
            placeholder="Search dishes, wines…"
            placeholderTextColor={T.ghost}
            value={search}
            onChangeText={setSearch}
          />
          {search ? (
            <TouchableOpacity onPress={() => setSearch('')}>
              <Ionicons name="close-circle" size={18} color={T.ghost} />
            </TouchableOpacity>
          ) : null}
        </View>
      </View>

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={styles.categoriesScroll}
        contentContainerStyle={styles.categoriesContent}
      >
        {CATEGORIES.map((c, i) => (
          <TouchableOpacity
            key={c.id}
            onPress={() => setCat(c.id)}
            style={[
              styles.categoryChip,
              cat === c.id && styles.categoryChipActive,
              i > 0 && styles.categoryChipMargin,
            ]}
          >
            <Text style={styles.categoryIcon}>{c.icon}</Text>
            <Text style={[styles.categoryName, cat === c.id && styles.categoryNameActive]}>
              {c.name}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      <FlatList
        data={filtered}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.menuList}
        showsVerticalScrollIndicator={false}
        bounces={true}
        renderItem={({ item, index }) => (
          <SlideUp delay={index * 45}>
            <TouchableOpacity onPress={() => setDetail(item)} activeOpacity={0.9}>
              <Card style={styles.menuItem}>
                <Image source={{ uri: item.image }} style={styles.menuItemImage} />
                <View style={styles.menuItemContent}>
                  <View style={styles.menuItemHeader}>
                    <Text style={styles.menuItemName}>{item.name}</Text>
                    <Text style={styles.menuItemPrice}>${item.price.toFixed(2)}</Text>
                  </View>
                  <Text style={styles.menuItemSubtitle}>{item.subtitle}</Text>
                  <View style={styles.menuItemMeta}>
                    <Stars rating={item.rating} reviews={item.reviews} />
                    <Text style={styles.menuItemDot}>·</Text>
                    <Text style={styles.menuItemTime}>{item.prepTime}min</Text>
                    {item.tags[0] && <Badge label={item.tags[0]} style={styles.menuItemTag} />}
                  </View>
                </View>
              </Card>
            </TouchableOpacity>
          </SlideUp>
        )}
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <Text style={styles.emptyEmoji}>🔍</Text>
            <Text style={styles.emptyText}>No dishes found</Text>
          </View>
        }
      />

      <Sheet visible={!!detail} onClose={() => setDetail(null)} title={detail?.name}>
        {detail ? <ItemDetailSheet item={detail} onClose={() => setDetail(null)} /> : null}
      </Sheet>
    </View>
  );
}

function ItemDetailSheet({ item, onClose }) {
  const [qty, setQty] = useState(1);
  const [notes, setNotes] = useState('');
  
  const add = () => {
    for (let i = 0; i < qty; i++) {
      updateG(s => ({
        cart: [...s.cart, { ...item, cartId: Date.now() + i }],
        loyalty: s.loyalty + Math.floor(item.price),
      }));
    }
    Alert.alert('Added!', `${qty}× ${item.name} added to cart.`);
    onClose();
  };
  
  return (
    <ScrollView contentContainerStyle={styles.detailSheet} showsVerticalScrollIndicator={false}>
      <Image source={{ uri: item.image }} style={styles.detailImage} />
      <LinearGradient colors={['transparent', T.surface]} style={styles.detailGradient} />
      
      <View style={styles.detailContent}>
        <View style={styles.detailTags}>
          {item.tags.map(t => (
            <Badge key={t} label={t} style={styles.detailTag} />
          ))}
        </View>
        
        <Text style={styles.detailDescription}>{item.description}</Text>
        
        <View style={styles.detailStats}>
          <View style={styles.detailStat}>
            <Ionicons name="flame-outline" size={18} color={T.gold} />
            <Text style={styles.detailStatLabel}>{item.calories} cal</Text>
          </View>
          <View style={styles.detailStat}>
            <Ionicons name="time-outline" size={18} color={T.gold} />
            <Text style={styles.detailStatLabel}>{item.prepTime} min</Text>
          </View>
          <View style={styles.detailStat}>
            <Ionicons name="star-outline" size={18} color={T.gold} />
            <Text style={styles.detailStatLabel}>{item.rating}</Text>
          </View>
        </View>
        
        {item.allergens.length > 0 && (
          <Text style={styles.allergens}>Contains: {item.allergens.join(', ')}</Text>
        )}
        
        <LuxInput
          label="Special Notes (optional)"
          icon="create-outline"
          placeholder="Allergies, preferences…"
          value={notes}
          onChangeText={setNotes}
          multiline
        />
        
        <View style={styles.detailActions}>
          <View style={styles.quantitySelector}>
            <TouchableOpacity onPress={() => setQty(q => Math.max(1, q - 1))}>
              <Ionicons name="remove" size={20} color={T.gold} />
            </TouchableOpacity>
            <Text style={styles.quantityDisplay}>{qty}</Text>
            <TouchableOpacity onPress={() => setQty(q => q + 1)}>
              <Ionicons name="add" size={20} color={T.gold} />
            </TouchableOpacity>
          </View>
          <GoldButton
            label={`Add · $${(item.price * qty).toFixed(2)}`}
            onPress={add}
            style={styles.addButton}
          />
        </View>
      </View>
    </ScrollView>
  );
}

// ═══════════════════════════════════════════════════════════════
// RESERVATION SCREEN
// ═══════════════════════════════════════════════════════════════
function ReservationScreen() {
  const [g, upd] = useGlobal();
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [size, setSize] = useState(2);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [occasion, setOccasion] = useState('');
  const [loading, setLoading] = useState(false);
  
  const OCCASIONS = ['None', 'Birthday 🎂', 'Anniversary 💍', 'Business 💼', 'Date Night 🌹'];

  const book = () => {
    if (!date || !time || !name || !phone) {
      Alert.alert('Missing Info', 'Please fill in all required fields.');
      return;
    }
    
    setLoading(true);
    setTimeout(() => {
      upd(s => ({
        reservations: [...s.reservations, {
          id: `RES-${Date.now()}`,
          date,
          time,
          partySize: size,
          name,
          phone,
          occasion: occasion === 'None' ? '' : occasion,
          status: 'pending',
          created: new Date().toLocaleString(),
        }],
        loyalty: s.loyalty + 100,
      }));
      setLoading(false);
      setDate('');
      setTime('');
      setName('');
      setPhone('');
      setOccasion('');
      setSize(2);
      Alert.alert('✦ Reservation Requested', 'Confirmation within 15 minutes.\n\n+100 loyalty points!');
    }, 1400);
  };

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={T.obsidian} />
      
      <Header title="Reserve" subtitle="Book a Table" />
      
      <ScrollView contentContainerStyle={styles.reservationContent} showsVerticalScrollIndicator={false} bounces={true}>
        <FadeIn>
          <Card style={styles.reservationCard}>
            <Text style={styles.cardTitle}>Reservation Details</Text>
            
            <LuxInput
              label="Your Name"
              icon="person-outline"
              placeholder="Full name"
              value={name}
              onChangeText={setName}
              autoCapitalize="words"
            />
            
            <LuxInput
              label="Phone"
              icon="call-outline"
              placeholder="+1 (555) 000-0000"
              value={phone}
              onChangeText={setPhone}
              keyboardType="phone-pad"
            />
            
            <LuxInput
              label="Date"
              icon="calendar-outline"
              placeholder="MM/DD/YYYY"
              value={date}
              onChangeText={setDate}
            />

            <View style={styles.timeSection}>
              <Text style={styles.inputLabel}>Preferred Time</Text>
              <View style={styles.timeGrid}>
                {TIME_SLOTS.map(slot => (
                  <TouchableOpacity
                    key={slot}
                    onPress={() => setTime(slot)}
                    style={[styles.timeSlot, time === slot && styles.timeSlotActive]}
                  >
                    <Text style={[styles.timeSlotText, time === slot && styles.timeSlotTextActive]}>
                      {slot}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>

            <View style={styles.sizeSection}>
              <Text style={styles.inputLabel}>Party Size</Text>
              <View style={styles.sizeControls}>
                <TouchableOpacity onPress={() => setSize(s => Math.max(1, s - 1))}>
                  <Ionicons name="remove-circle-outline" size={36} color={T.gold} />
                </TouchableOpacity>
                <View style={styles.sizeDisplay}>
                  <Text style={styles.sizeNumber}>{size}</Text>
                  <Text style={styles.sizeLabel}>{size === 1 ? 'Guest' : 'Guests'}</Text>
                </View>
                <TouchableOpacity onPress={() => setSize(s => Math.min(20, s + 1))}>
                  <Ionicons name="add-circle-outline" size={36} color={T.gold} />
                </TouchableOpacity>
              </View>
            </View>

            <View style={styles.occasionSection}>
              <Text style={styles.inputLabel}>Occasion</Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                {OCCASIONS.map((occ, i) => {
                  const val = occ === 'None' ? '' : occ;
                  return (
                    <TouchableOpacity
                      key={occ}
                      onPress={() => setOccasion(val)}
                      style={[
                        styles.occasionChip,
                        occasion === val && styles.occasionChipActive,
                        i > 0 && styles.occasionChipMargin,
                      ]}
                    >
                      <Text style={[styles.occasionText, occasion === val && styles.occasionTextActive]}>
                        {occ}
                      </Text>
                    </TouchableOpacity>
                  );
                })}
              </ScrollView>
            </View>

            <GoldButton
              label="Request Reservation"
              onPress={book}
              loading={loading}
              icon="calendar-outline"
              style={styles.reserveButton}
            />
          </Card>
        </FadeIn>

        {g.reservations.length > 0 && (
          <SlideUp delay={150}>
            <Text style={styles.sectionTitle}>My Reservations</Text>
            {g.reservations.map(res => (
              <Card key={res.id} style={styles.reservationItem}>
                <View style={styles.reservationItemContent}>
                  <View style={styles.reservationHeader}>
                    <Text style={styles.reservationName}>{res.name}</Text>
                    <View style={[
                      styles.reservationStatus,
                      { backgroundColor: res.status === 'confirmed' ? T.success + '22' : T.warning + '22' }
                    ]}>
                      <Text style={[
                        styles.reservationStatusText,
                        { color: res.status === 'confirmed' ? T.success : T.warning }
                      ]}>
                        {res.status}
                      </Text>
                    </View>
                  </View>
                  <Text style={styles.reservationDetails}>
                    {res.date} · {res.time} · Party of {res.partySize}
                  </Text>
                  {res.occasion && <Text style={styles.reservationOccasion}>{res.occasion}</Text>}
                  <Text style={styles.reservationId}>{res.id}</Text>
                </View>
              </Card>
            ))}
          </SlideUp>
        )}
        
        <View style={styles.bottomSpacer} />
      </ScrollView>
    </View>
  );
}

// ═══════════════════════════════════════════════════════════════
// CART SCREEN
// ═══════════════════════════════════════════════════════════════
function CartScreen() {
  const [g, upd] = useGlobal();
  const [pickup, setPickup] = useState('');
  const [loading, setLoading] = useState(false);

  const grouped = g.cart.reduce((acc, ci) => {
    const ex = acc.find(a => a.id === ci.id);
    if (ex) ex.qty++;
    else acc.push({ ...ci, qty: 1 });
    return acc;
  }, []);

  const subtotal = g.cart.reduce((s, i) => s + i.price, 0);
  const tax = subtotal * 0.08;
  const service = subtotal * 0.18;
  const total = subtotal + tax + service;

  const addOne = (item) => upd(s => ({ cart: [...s.cart, { ...item, cartId: Date.now() }] }));

  const removeOne = (itemId) => {
    upd(s => {
      const cart = [...s.cart];
      const idx = lastIndexOf(cart, c => c.id === itemId);
      if (idx !== -1) cart.splice(idx, 1);
      return { cart };
    });
  };

  const clearItem = (itemId) => upd(s => ({ cart: s.cart.filter(c => c.id !== itemId) }));

  const placeOrder = () => {
    if (g.cart.length === 0) {
      Alert.alert('Empty Cart', 'Add some items first.');
      return;
    }
    if (!pickup) {
      Alert.alert('Pickup Time', 'Please select a time.');
      return;
    }
    
    setLoading(true);
    setTimeout(() => {
      const orderId = `ORD-${Math.floor(Math.random() * 9000) + 1000}`;
      upd(s => ({
        cart: [],
        loyalty: s.loyalty + Math.floor(total),
        orders: [...s.orders, {
          id: orderId,
          customer: 'You',
          table: 'Takeout',
          items: grouped.map(i => ({ name: i.name, qty: i.qty, price: i.price })),
          total,
          status: 'received',
          time: pickup,
          notes: '',
          priority: 'normal',
        }],
      }));
      setLoading(false);
      setPickup('');
      Alert.alert(`✦ Order ${orderId}`, `Total: $${total.toFixed(2)}\nPickup: ${pickup}\n+${Math.floor(total)} loyalty pts!`);
    }, 1600);
  };

  if (g.cart.length === 0) {
    return (
      <View style={styles.container}>
        <StatusBar barStyle="light-content" backgroundColor={T.obsidian} />
        <Header title="Cart" subtitle="Your Order" />
        <View style={styles.emptyCart}>
          <Text style={styles.emptyCartEmoji}>🛒</Text>
          <Text style={styles.emptyCartTitle}>Your cart is empty</Text>
          <Text style={styles.emptyCartSubtitle}>Explore the menu to add dishes</Text>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={T.obsidian} />
      
      <Header title={`Cart (${g.cart.length})`} subtitle="Your Order" />
      
      <ScrollView contentContainerStyle={styles.cartContent} showsVerticalScrollIndicator={false} bounces={true}>
        <FadeIn>
          <Card style={styles.cartItems}>
            {grouped.map((item, idx) => (
              <View key={item.id}>
                <View style={styles.cartItem}>
                  <Image source={{ uri: item.image }} style={styles.cartItemImage} />
                  <View style={styles.cartItemInfo}>
                    <Text style={styles.cartItemName}>{item.name}</Text>
                    <Text style={styles.cartItemPrice}>${item.price.toFixed(2)} each</Text>
                  </View>
                  <View style={styles.cartItemControls}>
                    <TouchableOpacity onPress={() => removeOne(item.id)}>
                      <Ionicons name="remove-circle-outline" size={22} color={T.gold} />
                    </TouchableOpacity>
                    <Text style={styles.cartItemQty}>{item.qty}</Text>
                    <TouchableOpacity onPress={() => addOne(item)}>
                      <Ionicons name="add-circle-outline" size={22} color={T.gold} />
                    </TouchableOpacity>
                  </View>
                  <View style={styles.cartItemTotal}>
                    <Text style={styles.cartItemTotalPrice}>${(item.price * item.qty).toFixed(2)}</Text>
                    <TouchableOpacity onPress={() => clearItem(item.id)}>
                      <Ionicons name="trash-outline" size={18} color={T.danger + 'AA'} />
                    </TouchableOpacity>
                  </View>
                </View>
                {idx < grouped.length - 1 && <Divider />}
              </View>
            ))}
          </Card>
        </FadeIn>

        <SlideUp delay={80}>
          <Card style={styles.summaryCard}>
            <Text style={styles.cardTitle}>Summary</Text>
            
            {[
              ['Subtotal', subtotal],
              ['Tax (8%)', tax],
              ['Service (18%)', service],
            ].map(([label, val]) => (
              <View key={label} style={styles.summaryRow}>
                <Text style={styles.summaryLabel}>{label}</Text>
                <Text style={styles.summaryValue}>${val.toFixed(2)}</Text>
              </View>
            ))}
            
            <Divider style={styles.summaryDivider} />
            
            <View style={styles.totalRow}>
              <Text style={styles.totalLabel}>Total</Text>
              <Text style={styles.totalValue}>${total.toFixed(2)}</Text>
            </View>
            
            <View style={styles.loyaltyEarn}>
              <Ionicons name="diamond-outline" size={14} color={T.gold} />
              <Text style={styles.loyaltyEarnText}>You'll earn +{Math.floor(total)} loyalty points</Text>
            </View>
          </Card>
        </SlideUp>

        <SlideUp delay={140}>
          <Card style={styles.pickupCard}>
            <Text style={styles.cardTitle}>Pickup Time</Text>
            <View style={styles.pickupGrid}>
              {TIME_SLOTS.map(slot => (
                <TouchableOpacity
                  key={slot}
                  onPress={() => setPickup(slot)}
                  style={[styles.pickupSlot, pickup === slot && styles.pickupSlotActive]}
                >
                  <Text style={[styles.pickupSlotText, pickup === slot && styles.pickupSlotTextActive]}>
                    {slot}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </Card>
        </SlideUp>

        <SlideUp delay={200}>
          <GoldButton
            label={`Place Order · $${total.toFixed(2)}`}
            onPress={placeOrder}
            loading={loading}
            icon="checkmark-circle-outline"
            style={styles.placeOrderButton}
          />
        </SlideUp>
        
        <View style={styles.bottomSpacer} />
      </ScrollView>
    </View>
  );
}

// ═══════════════════════════════════════════════════════════════
// PROFILE SCREEN
// ═══════════════════════════════════════════════════════════════
function ProfileScreen({ name, onLogout }) {
  const [g] = useGlobal();
  const [notif, setNotif] = useState(true);
  const [news, setNews] = useState(false);

  const tier = g.loyalty < 500 ? { name: 'Bronze', next: 500, color: '#CD7F32' }
    : g.loyalty < 1500 ? { name: 'Silver', next: 1500, color: '#C0C0C0' }
    : g.loyalty < 3000 ? { name: 'Gold', next: 3000, color: T.gold }
    : { name: 'Platinum', next: null, color: '#E5E4E2' };
  
  const prog = tier.next ? Math.min(g.loyalty / tier.next, 1) : 1;

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={T.obsidian} />
      
      <Header title="Profile" subtitle="Lumière" />
      
      <ScrollView contentContainerStyle={styles.profileContent} showsVerticalScrollIndicator={false} bounces={true}>
        <FadeIn>
          <View style={styles.profileHeader}>
            <LinearGradient
              colors={[T.gold + '22', T.gold + '08']}
              style={styles.profileAvatar}
            >
              <Text style={styles.avatarEmoji}>👤</Text>
            </LinearGradient>
            <Text style={styles.profileName}>{name || 'Guest'}</Text>
            <Text style={styles.profileMember}>Lumière Member</Text>
          </View>
        </FadeIn>

        <SlideUp delay={100}>
          <LinearGradient colors={['#1A1508', '#2A2010']} style={styles.loyaltyCard}>
            <View style={styles.loyaltyHeader}>
              <View>
                <Text style={styles.loyaltyLabel}>Loyalty Status</Text>
                <Text style={[styles.loyaltyTier, { color: tier.color }]}>{tier.name}</Text>
              </View>
              <Ionicons name="diamond" size={36} color={tier.color} />
            </View>
            
            <Text style={styles.loyaltyPoints}>
              {g.loyalty.toLocaleString()}
              <Text style={styles.loyaltyPointsUnit}> points</Text>
            </Text>
            
            {tier.next && (
              <>
                <View style={styles.progressBar}>
                  <View style={[styles.progressFill, { width: `${prog * 100}%` }]} />
                </View>
                <Text style={styles.progressText}>
                  {(tier.next - g.loyalty).toLocaleString()} pts to next tier
                </Text>
              </>
            )}
          </LinearGradient>
        </SlideUp>

        <SlideUp delay={180}>
          <View style={styles.statsGrid}>
            {[
              ['Orders', g.orders.length],
              ['Reservations', g.reservations.length],
              ['Reviews', 0],
            ].map(([label, val], i) => (
              <Card key={label} style={[styles.statBox, i > 0 && styles.statBoxMargin]}>
                <Text style={styles.statBoxNumber}>{val}</Text>
                <Text style={styles.statBoxLabel}>{label}</Text>
              </Card>
            ))}
          </View>
        </SlideUp>

        <SlideUp delay={250}>
          <Card style={styles.settingsCard}>
            {[
              { label: 'Push Notifications', icon: 'notifications-outline', toggle: true, value: notif, onChange: setNotif },
              { label: 'Newsletter', icon: 'mail-outline', toggle: true, value: news, onChange: setNews },
              { label: 'Dietary Preferences', icon: 'leaf-outline', toggle: false },
              { label: 'Payment Methods', icon: 'card-outline', toggle: false },
              { label: 'Help & Support', icon: 'help-circle-outline', toggle: false },
            ].map((row, idx, arr) => (
              <View key={row.label}>
                <View style={styles.settingRow}>
                  <Ionicons name={row.icon} size={20} color={T.gold} style={styles.settingIcon} />
                  <Text style={styles.settingLabel}>{row.label}</Text>
                  {row.toggle ? (
                    <Switch
                      value={row.value}
                      onValueChange={row.onChange}
                      trackColor={{ false: T.muted, true: T.gold + '66' }}
                      thumbColor={row.value ? T.gold : T.ghost}
                    />
                  ) : (
                    <Ionicons name="chevron-forward" size={16} color={T.ghost} />
                  )}
                </View>
                {idx < arr.length - 1 && <Divider style={styles.settingDivider} />}
              </View>
            ))}
          </Card>
        </SlideUp>

        <SlideUp delay={330}>
          <GoldButton
            label="Sign Out"
            onPress={onLogout}
            variant="outline"
            icon="log-out-outline"
            style={styles.signOutButton}
          />
        </SlideUp>
        
        <View style={styles.bottomSpacer} />
      </ScrollView>
    </View>
  );
}

// ═══════════════════════════════════════════════════════════════
// MANAGER APP
// ═══════════════════════════════════════════════════════════════
function ManagerApp({ name, onLogout }) {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarStyle: styles.tabBar,
        tabBarActiveTintColor: T.success,
        tabBarInactiveTintColor: T.ghost,
        tabBarLabelStyle: styles.tabBarLabel,
        tabBarIcon: ({ focused, color }) => {
          const icons = {
            Dashboard: focused ? 'grid' : 'grid-outline',
            Orders: focused ? 'clipboard' : 'clipboard-outline',
            'Manage Menu': focused ? 'restaurant' : 'restaurant-outline',
            Reservations: focused ? 'calendar' : 'calendar-outline',
          };
          return <Ionicons name={icons[route.name]} size={22} color={color} />;
        },
      })}
    >
      <Tab.Screen name="Dashboard">{p => <ManagerDashboard {...p} name={name} onLogout={onLogout} />}</Tab.Screen>
      <Tab.Screen name="Orders" component={ManagerOrders} />
      <Tab.Screen name="Manage Menu" component={ManagerMenu} />
      <Tab.Screen name="Reservations" component={ManagerReservations} />
    </Tab.Navigator>
  );
}

// ═══════════════════════════════════════════════════════════════
// MANAGER DASHBOARD
// ═══════════════════════════════════════════════════════════════
function ManagerDashboard({ name, onLogout }) {
  const [g] = useGlobal();
  const active = g.orders.filter(o => o.status !== 'picked up').length;
  const revenue = g.orders.reduce((s, o) => s + o.total, 0);
  
  const stats = [
    { label: 'Active Orders', value: active, icon: 'flame', color: T.danger },
    { label: 'Revenue', value: `$${revenue.toFixed(0)}`, icon: 'trending-up', color: T.success },
    { label: 'Reservations', value: g.reservations.length, icon: 'calendar', color: T.gold },
    { label: 'Menu Items', value: g.menuItems.length, icon: 'restaurant', color: T.info },
  ];
  
  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={T.obsidian} />
      
      <View style={styles.managerHeader}>
        <View>
          <Text style={styles.managerGreeting}>Management</Text>
          <Text style={styles.managerTitle}>Dashboard</Text>
        </View>
        <View style={styles.managerActions}>
          <View style={styles.liveIndicator}>
            <View style={styles.liveDot} />
            <Text style={styles.liveText}>Live</Text>
          </View>
          <TouchableOpacity onPress={onLogout}>
            <Ionicons name="log-out-outline" size={22} color={T.ghost} />
          </TouchableOpacity>
        </View>
      </View>
      
      <ScrollView contentContainerStyle={styles.managerContent} showsVerticalScrollIndicator={false} bounces={true}>
        <FadeIn>
          <View style={styles.statsGrid}>
            {stats.map((s, i) => (
              <View key={s.label} style={[styles.statCard, i % 2 === 1 && styles.statCardEven]}>
                <Card style={styles.statCardInner}>
                  <View style={[styles.statIcon, { backgroundColor: s.color + '18' }]}>
                    <Ionicons name={s.icon} size={20} color={s.color} />
                  </View>
                  <Text style={styles.statCardValue}>{s.value}</Text>
                  <Text style={styles.statCardLabel}>{s.label}</Text>
                </Card>
              </View>
            ))}
          </View>
        </FadeIn>
        
        <SlideUp delay={150}>
          <Text style={styles.sectionTitle}>Live Orders</Text>
          {g.orders.slice(0, 4).map(order => (
            <Card key={order.id} style={styles.liveOrder}>
              <View style={styles.liveOrderContent}>
                <View style={styles.liveOrderHeader}>
                  <Text style={styles.liveOrderId}>{order.id}</Text>
                  <OrderStatusBadge status={order.status} />
                </View>
                <Text style={styles.liveOrderDetails}>
                  {order.customer} · {order.table} · {order.time}
                </Text>
                <Text style={styles.liveOrderTotal}>${order.total.toFixed(2)}</Text>
              </View>
            </Card>
          ))}
        </SlideUp>
        
        <View style={styles.bottomSpacer} />
      </ScrollView>
    </View>
  );
}

// ═══════════════════════════════════════════════════════════════
// MANAGER ORDERS
// ═══════════════════════════════════════════════════════════════
function ManagerOrders() {
  const [g, upd] = useGlobal();
  const [filter, setFilter] = useState('all');
  
  const NEXT = { received: 'preparing', preparing: 'ready', ready: 'picked up' };
  const LABEL = { received: 'Start Prep', preparing: 'Mark Ready', ready: 'Picked Up' };
  
  const advance = (id) => upd(s => ({
    orders: s.orders.map(o => o.id === id && NEXT[o.status] ? { ...o, status: NEXT[o.status] } : o)
  }));
  
  const filtered = filter === 'all' ? g.orders : g.orders.filter(o => o.status === filter);

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={T.obsidian} />
      
      <Header title="Orders" subtitle="Live Kitchen" />
      
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={styles.filterScroll}
        contentContainerStyle={styles.filterContent}
      >
        {['all', 'received', 'preparing', 'ready', 'picked up'].map((f, i) => (
          <TouchableOpacity
            key={f}
            onPress={() => setFilter(f)}
            style={[
              styles.filterChip,
              filter === f && styles.filterChipActive,
              i > 0 && styles.filterChipMargin,
            ]}
          >
            <Text style={[styles.filterText, filter === f && styles.filterTextActive]}>
              {f}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
      
      <FlatList
        data={filtered}
        keyExtractor={o => o.id}
        contentContainerStyle={styles.ordersList}
        showsVerticalScrollIndicator={false}
        bounces={true}
        renderItem={({ item, index }) => (
          <SlideUp delay={index * 50}>
            <Card style={styles.orderCard}>
              <View style={styles.orderCardContent}>
                <View style={styles.orderHeader}>
                  <View>
                    <Text style={styles.orderId}>{item.id}</Text>
                    <Text style={styles.orderCustomer}>{item.customer} · {item.table}</Text>
                  </View>
                  <View style={styles.orderMeta}>
                    <OrderStatusBadge status={item.status} />
                    <Text style={styles.orderTime}>{item.time}</Text>
                  </View>
                </View>
                
                <View style={styles.orderItems}>
                  {item.items.map((it, idx) => (
                    <Text key={idx} style={styles.orderItem}>
                      {it.qty}× {it.name} — ${(it.qty * it.price).toFixed(2)}
                    </Text>
                  ))}
                </View>
                
                {item.notes && (
                  <View style={styles.orderNotes}>
                    <Ionicons name="warning-outline" size={14} color={T.warning} />
                    <Text style={styles.orderNotesText}>{item.notes}</Text>
                  </View>
                )}
                
                <View style={styles.orderFooter}>
                  <Text style={styles.orderTotal}>${item.total.toFixed(2)}</Text>
                  {NEXT[item.status] && (
                    <TouchableOpacity
                      onPress={() => advance(item.id)}
                      style={styles.advanceButton}
                    >
                      <Text style={styles.advanceButtonText}>{LABEL[item.status]}</Text>
                    </TouchableOpacity>
                  )}
                </View>
              </View>
            </Card>
          </SlideUp>
        )}
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <Text style={styles.emptyEmoji}>📋</Text>
            <Text style={styles.emptyText}>No orders for this filter</Text>
          </View>
        }
      />
    </View>
  );
}

// ═══════════════════════════════════════════════════════════════
// MANAGER MENU
// ═══════════════════════════════════════════════════════════════
function ManagerMenu() {
  const [g, upd] = useGlobal();
  const [showAdd, setShowAdd] = useState(false);
  const EMOJIS = ['🍽️', '🥩', '🦞', '🍄', '🐟', '🥗', '🍫', '🧀', '🥂', '🍕', '🍝', '🍮', '🥘', '🦐', '🫕'];
  const BLANK = { name: '', price: '', category: 'mains', description: '', emoji: '🍽️' };
  const [form, setForm] = useState(BLANK);

  const deleteItem = (id) => Alert.alert('Delete', 'Remove this item from the menu?', [
    { text: 'Cancel', style: 'cancel' },
    {
      text: 'Delete',
      style: 'destructive',
      onPress: () => upd(s => ({ menuItems: s.menuItems.filter(i => i.id !== id) })),
    },
  ]);

  const addItem = () => {
    if (!form.name.trim() || !form.price) {
      Alert.alert('Required', 'Name and price are required.');
      return;
    }
    const parsed = parseFloat(form.price);
    if (isNaN(parsed) || parsed <= 0) {
      Alert.alert('Invalid Price', 'Please enter a valid positive price.');
      return;
    }
    
    upd(s => ({
      menuItems: [...s.menuItems, {
        ...form,
        id: Date.now().toString(),
        price: parsed,
        subtitle: form.category,
        rating: 4.5,
        reviews: 0,
        calories: 0,
        prepTime: 15,
        allergens: [],
        tags: ['New'],
        available: true,
      }],
    }));
    
    setShowAdd(false);
    setForm(BLANK);
    Alert.alert('✦ Added', 'New item published to the menu!');
  };

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={T.obsidian} />
      
      <Header
        title="Menu"
        subtitle="Manage"
        rightAction={{ icon: 'add-circle-outline', onPress: () => setShowAdd(true) }}
      />
      
      <FlatList
        data={g.menuItems}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.managerMenuList}
        showsVerticalScrollIndicator={false}
        bounces={true}
        renderItem={({ item, index }) => (
          <SlideUp delay={index * 40}>
            <Card style={styles.managerMenuItem}>
              <Image source={{ uri: item.image }} style={styles.managerMenuImage} />
              <View style={styles.managerMenuInfo}>
                <Text style={styles.managerMenuName}>{item.name}</Text>
                <Text style={styles.managerMenuCategory}>{item.category}</Text>
              </View>
              <Text style={styles.managerMenuPrice}>${item.price.toFixed(2)}</Text>
              <TouchableOpacity onPress={() => deleteItem(item.id)}>
                <Ionicons name="trash-outline" size={20} color={T.danger + 'AA'} />
              </TouchableOpacity>
            </Card>
          </SlideUp>
        )}
      />
      
      <Sheet visible={showAdd} onClose={() => { setShowAdd(false); setForm(BLANK); }} title="Add Menu Item">
        <ScrollView contentContainerStyle={styles.addMenuSheet} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
          <View style={styles.emojiPicker}>
            <Text style={styles.inputLabel}>Icon</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              {EMOJIS.map((e, i) => (
                <TouchableOpacity
                  key={i}
                  onPress={() => setForm(f => ({ ...f, emoji: e }))}
                  style={[styles.emojiOption, form.emoji === e && styles.emojiOptionActive]}
                >
                  <Text style={styles.emojiText}>{e}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
          
          <LuxInput
            label="Item Name"
            icon="restaurant-outline"
            placeholder="e.g. Truffle Pasta"
            value={form.name}
            onChangeText={t => setForm(f => ({ ...f, name: t }))}
          />
          
          <LuxInput
            label="Price ($)"
            icon="pricetag-outline"
            placeholder="0.00"
            value={form.price}
            onChangeText={t => setForm(f => ({ ...f, price: t }))}
            keyboardType="decimal-pad"
          />
          
          <LuxInput
            label="Description"
            icon="document-text-outline"
            placeholder="Brief description"
            value={form.description}
            onChangeText={t => setForm(f => ({ ...f, description: t }))}
            multiline
          />
          
          <View style={styles.categoryPicker}>
            <Text style={styles.inputLabel}>Category</Text>
            <View style={styles.categoryGrid}>
              {['starters', 'mains', 'signature', 'desserts', 'wines'].map((cat, i) => (
                <TouchableOpacity
                  key={cat}
                  onPress={() => setForm(f => ({ ...f, category: cat }))}
                  style={[
                    styles.categoryOption,
                    form.category === cat && styles.categoryOptionActive,
                    i > 0 && styles.categoryOptionMargin,
                  ]}
                >
                  <Text style={[styles.categoryOptionText, form.category === cat && styles.categoryOptionTextActive]}>
                    {cat}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
          
          <GoldButton
            label="Add to Menu"
            onPress={addItem}
            icon="add-circle-outline"
            style={styles.addButton}
          />
        </ScrollView>
      </Sheet>
    </View>
  );
}

// ═══════════════════════════════════════════════════════════════
// MANAGER RESERVATIONS
// ═══════════════════════════════════════════════════════════════
function ManagerReservations() {
  const [g, upd] = useGlobal();
  const setStatus = (id, status) => upd(s => ({
    reservations: s.reservations.map(r => r.id === id ? { ...r, status } : r)
  }));

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={T.obsidian} />
      
      <Header title="Reservations" subtitle="Table Management" />
      
      <FlatList
        data={g.reservations}
        keyExtractor={r => r.id}
        contentContainerStyle={styles.reservationsList}
        showsVerticalScrollIndicator={false}
        bounces={true}
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <Text style={styles.emptyEmoji}>🗓️</Text>
            <Text style={styles.emptyTitle}>No reservations yet</Text>
            <Text style={styles.emptySubtitle}>Customer bookings will appear here</Text>
          </View>
        }
        renderItem={({ item, index }) => (
          <SlideUp delay={index * 60}>
            <Card style={styles.reservationCard}>
              <View style={styles.reservationCardContent}>
                <View style={styles.reservationCardHeader}>
                  <View>
                    <Text style={styles.reservationCardName}>{item.name}</Text>
                    <Text style={styles.reservationCardId}>{item.id}</Text>
                  </View>
                  <View style={[
                    styles.reservationCardStatus,
                    {
                      backgroundColor: item.status === 'confirmed' ? T.success + '22' :
                        item.status === 'cancelled' ? T.danger + '22' : T.warning + '22'
                    }
                  ]}>
                    <Text style={[
                      styles.reservationCardStatusText,
                      {
                        color: item.status === 'confirmed' ? T.success :
                          item.status === 'cancelled' ? T.danger : T.warning
                      }
                    ]}>
                      {item.status}
                    </Text>
                  </View>
                </View>
                
                <View style={styles.reservationCardDetails}>
                  <View style={styles.reservationDetail}>
                    <Ionicons name="calendar-outline" size={14} color={T.ghost} />
                    <Text style={styles.reservationDetailText}>{item.date}</Text>
                  </View>
                  <View style={styles.reservationDetail}>
                    <Ionicons name="time-outline" size={14} color={T.ghost} />
                    <Text style={styles.reservationDetailText}>{item.time}</Text>
                  </View>
                  <View style={styles.reservationDetail}>
                    <Ionicons name="people-outline" size={14} color={T.ghost} />
                    <Text style={styles.reservationDetailText}>{item.partySize}</Text>
                  </View>
                </View>
                
                {item.occasion && (
                  <View style={styles.reservationOccasion}>
                    <Ionicons name="gift-outline" size={14} color={T.gold} />
                    <Text style={styles.reservationOccasionText}>{item.occasion}</Text>
                  </View>
                )}
                
                <Text style={styles.reservationPhone}>{item.phone}</Text>
                
                {item.status === 'pending' && (
                  <View style={styles.reservationActions}>
                    <TouchableOpacity
                      onPress={() => setStatus(item.id, 'confirmed')}
                      style={[styles.reservationAction, styles.confirmAction]}
                    >
                      <Text style={styles.confirmActionText}>Confirm</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                      onPress={() => setStatus(item.id, 'cancelled')}
                      style={[styles.reservationAction, styles.declineAction]}
                    >
                      <Text style={styles.declineActionText}>Decline</Text>
                    </TouchableOpacity>
                  </View>
                )}
              </View>
            </Card>
          </SlideUp>
        )}
      />
    </View>
  );
}

// ═══════════════════════════════════════════════════════════════
// DIVIDER COMPONENT
// ═══════════════════════════════════════════════════════════════
function Divider({ style }) {
  return <View style={[styles.divider, style]} />;
}

// ═══════════════════════════════════════════════════════════════
// ROOT COMPONENT
// ═══════════════════════════════════════════════════════════════
export default function App() {
  const [auth, setAuth] = useState({ loggedIn: false, role: '', name: '' });
  
  const login = (role, name) => setAuth({ loggedIn: true, role, name });
  
  const logout = () => Alert.alert('Sign Out', 'Are you sure?', [
    { text: 'Cancel', style: 'cancel' },
    { text: 'Sign Out', style: 'destructive', onPress: () => setAuth({ loggedIn: false, role: '', name: '' }) },
  ]);

  return (
    <>
      <StatusBar barStyle="light-content" backgroundColor={T.obsidian} />
      <NavigationContainer>
        <Stack.Navigator screenOptions={{ headerShown: false }}>
          {!auth.loggedIn ? (
            <Stack.Screen name="Auth">
              {props => <AuthScreen {...props} onLogin={login} />}
            </Stack.Screen>
          ) : auth.role === 'manager' ? (
            <Stack.Screen name="Manager">
              {props => <ManagerApp {...props} name={auth.name} onLogout={logout} />}
            </Stack.Screen>
          ) : (
            <Stack.Screen name="Customer">
              {props => <CustomerApp {...props} name={auth.name} onLogout={logout} />}
            </Stack.Screen>
          )}
        </Stack.Navigator>
      </NavigationContainer>
    </>
  );
}

// ═══════════════════════════════════════════════════════════════
// STYLES
// ═══════════════════════════════════════════════════════════════
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: T.obsidian,
  },
  flex1: {
    flex: 1,
  },
  
  // Auth Styles
  authBackground: {
    ...StyleSheet.absoluteFillObject,
    width: SW,
    height: SH,
  },
  authScrollContent: {
    flexGrow: 1,
    paddingHorizontal: T.sp.lg,
    paddingBottom: T.sp.xl,
  },
  logoContainer: {
    alignItems: 'center',
    marginTop: SH * 0.08,
    marginBottom: T.sp.xl,
  },
  logoGlow: {
    width: 80,
    height: 80,
    borderRadius: 40,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: T.sp.md,
    borderWidth: 2,
    borderColor: T.gold + '40',
  },
  logoEmoji: {
    fontSize: 32,
    color: T.gold,
  },
  logoText: {
    fontSize: T.font.hero,
    fontWeight: '900',
    color: T.gold,
    letterSpacing: 8,
    textTransform: 'uppercase',
  },
  logoSubtext: {
    color: T.ghost,
    fontSize: T.font.micro,
    letterSpacing: 4,
    textTransform: 'uppercase',
    marginTop: 4,
  },
  modeToggle: {
    flexDirection: 'row',
    backgroundColor: T.surface,
    borderRadius: T.r.md,
    borderWidth: 1,
    borderColor: T.border,
    marginBottom: T.sp.xl,
    padding: 4,
  },
  modeButton: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: T.r.sm + 2,
    alignItems: 'center',
  },
  modeButtonActive: {
    backgroundColor: T.gold,
  },
  modeButtonText: {
    color: T.ghost,
    fontWeight: '700',
    fontSize: T.font.body,
  },
  modeButtonTextActive: {
    color: T.obsidian,
  },
  formContainer: {
    marginBottom: T.sp.lg,
  },
  passwordContainer: {
    marginBottom: T.sp.md,
  },
  inputLabel: {
    color: T.gold,
    fontSize: T.font.micro,
    fontWeight: '700',
    letterSpacing: 2,
    textTransform: 'uppercase',
    marginBottom: 8,
  },
  passwordWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: T.surface,
    borderRadius: T.r.md,
    borderWidth: 1,
    borderColor: T.border,
    paddingHorizontal: T.sp.md,
    height: 52,
  },
  passwordInput: {
    flex: 1,
    color: T.cream,
    fontSize: T.font.body,
    marginLeft: 10,
  },
  roleContainer: {
    marginBottom: T.sp.lg,
  },
  roleButtons: {
    flexDirection: 'row',
  },
  roleButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    borderRadius: T.r.md,
    borderWidth: 1.5,
    borderColor: T.border,
    backgroundColor: T.surface,
  },
  roleButtonActive: {
    borderColor: T.gold,
    backgroundColor: T.gold + '15',
  },
  roleButtonMargin: {
    marginLeft: T.sp.sm,
  },
  roleIcon: {
    marginRight: 6,
  },
  roleText: {
    color: T.ghost,
    fontWeight: '700',
    fontSize: T.font.body,
  },
  roleTextActive: {
    color: T.gold,
  },
  submitButton: {
    marginBottom: T.sp.lg,
  },
  demoCard: {
    borderRadius: T.r.md,
    borderWidth: 1,
    borderColor: T.border,
    padding: T.sp.md,
  },
  demoTitle: {
    color: T.gold,
    fontSize: T.font.micro,
    fontWeight: '700',
    letterSpacing: 2,
    textTransform: 'uppercase',
    marginBottom: 8,
  },
  demoText: {
    color: T.silver,
    fontSize: T.font.caption,
    lineHeight: 20,
  },
  demoLabel: {
    color: T.cream,
  },
  
  // Header Styles
  header: {
    paddingHorizontal: T.sp.lg,
    paddingTop: T.sp.md,
    paddingBottom: T.sp.sm,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  headerLeft: {
    padding: 4,
  },
  headerRight: {
    padding: 4,
  },
  headerPlaceholder: {
    width: 32,
  },
  headerCenter: {
    alignItems: 'center',
    flex: 1,
  },
  headerSubtitle: {
    color: T.gold,
    fontSize: T.font.micro,
    fontWeight: '700',
    letterSpacing: 3,
    textTransform: 'uppercase',
    marginBottom: 2,
  },
  headerTitle: {
    color: T.cream,
    fontSize: T.font.title,
    fontWeight: '700',
    letterSpacing: 0.5,
  },
  
  // Home Styles
  homeHeader: {
    paddingHorizontal: T.sp.lg,
    paddingTop: T.sp.lg,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: T.sp.xl,
  },
  greeting: {
    color: T.ghost,
    fontSize: T.font.caption,
    letterSpacing: 1,
    marginBottom: 3,
  },
  userName: {
    color: T.cream,
    fontSize: T.font.heading,
    fontWeight: '800',
  },
  headerActions: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  logoutButton: {
    marginLeft: 10,
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: T.elevated,
    borderWidth: 1,
    borderColor: T.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  heroContainer: {
    height: 200,
    marginHorizontal: T.sp.lg,
    marginBottom: T.sp.xl,
    borderRadius: T.r.lg,
    overflow: 'hidden',
  },
  heroImage: {
    width: '100%',
    height: '100%',
  },
  heroOverlay: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'flex-end',
    padding: T.sp.lg,
  },
  heroContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  heroTitle: {
    color: T.cream,
    fontSize: T.font.title,
    fontWeight: '800',
  },
  featuredSection: {
    marginBottom: T.sp.xl,
  },
  featuredScroll: {
    paddingLeft: T.sp.lg,
    paddingRight: T.sp.md,
  },
  featuredCard: {
    marginRight: T.sp.md,
    width: SW * 0.7,
  },
  featuredImage: {
    width: '100%',
    height: 150,
  },
  featuredGradient: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'flex-end',
  },
  featuredContent: {
    padding: T.sp.lg,
  },
  featuredHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: T.sp.sm,
  },
  featuredEmoji: {
    fontSize: 50,
  },
  featuredTags: {
    alignItems: 'flex-end',
  },
  featuredTag: {
    marginBottom: 4,
  },
  featuredName: {
    color: T.cream,
    fontSize: T.font.title,
    fontWeight: '800',
    marginBottom: 2,
  },
  featuredSubtitle: {
    color: T.ghost,
    fontSize: T.font.caption,
    marginBottom: T.sp.sm,
  },
  featuredFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: T.sp.sm,
  },
  featuredPrice: {
    color: T.gold,
    fontSize: T.font.title,
    fontWeight: '900',
  },
  featuredAddButton: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: T.gold + '22',
    borderWidth: 1,
    borderColor: T.gold,
    alignItems: 'center',
    justifyContent: 'center',
  },
  statsRow: {
    flexDirection: 'row',
    paddingHorizontal: T.sp.lg,
    marginBottom: T.sp.xl,
  },
  statCard: {
    flex: 1,
    backgroundColor: T.elevated,
    borderRadius: T.r.md,
    borderWidth: 1,
    borderColor: T.border,
    padding: T.sp.md,
    alignItems: 'center',
  },
  statCardMargin: {
    marginLeft: T.sp.sm,
  },
  statValue: {
    color: T.cream,
    fontSize: 13,
    fontWeight: '700',
    marginTop: 4,
  },
  statLabel: {
    color: T.ghost,
    fontSize: 10,
    letterSpacing: 0.5,
    marginTop: 2,
  },
  quickActions: {
    paddingHorizontal: T.sp.lg,
    marginBottom: T.sp.xl,
  },
  sectionTitle: {
    color: T.cream,
    fontSize: T.font.title,
    fontWeight: '800',
    marginBottom: T.sp.md,
  },
  actionButtons: {
    flexDirection: 'row',
  },
  actionButton: {
    flex: 1,
  },
  actionButtonMargin: {
    marginLeft: T.sp.sm,
  },
  actionGradient: {
    borderRadius: T.r.lg,
    padding: T.sp.lg,
    height: 100,
    justifyContent: 'space-between',
  },
  actionLabel: {
    color: T.obsidian,
    fontSize: 14,
    fontWeight: '800',
  },
  mostLovedSection: {
    paddingHorizontal: T.sp.lg,
    marginBottom: 40,
  },
  compactCard: {
    marginBottom: T.sp.sm,
  },
  compactContent: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: T.sp.md,
  },
  compactImage: {
    width: 58,
    height: 58,
    borderRadius: T.r.md,
    marginRight: T.sp.md,
  },
  compactInfo: {
    flex: 1,
  },
  compactName: {
    color: T.cream,
    fontSize: 15,
    fontWeight: '700',
    marginBottom: 3,
  },
  compactActions: {
    alignItems: 'flex-end',
  },
  compactPrice: {
    color: T.gold,
    fontSize: 15,
    fontWeight: '800',
    marginBottom: 6,
  },
  compactAddButton: {
    paddingHorizontal: 12,
    paddingVertical: 5,
    backgroundColor: T.gold + '22',
    borderRadius: T.r.full,
    borderWidth: 1,
    borderColor: T.gold + '55',
  },
  compactAddText: {
    color: T.gold,
    fontSize: 12,
    fontWeight: '700',
  },
  quantityControls: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  quantityText: {
    color: T.cream,
    fontSize: 15,
    fontWeight: '700',
    marginHorizontal: 8,
    minWidth: 16,
    textAlign: 'center',
  },
  
  // Explore Styles
  searchContainer: {
    paddingHorizontal: T.sp.lg,
    marginBottom: T.sp.md,
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: T.elevated,
    borderRadius: T.r.md,
    borderWidth: 1,
    borderColor: T.border,
    paddingHorizontal: T.sp.md,
    height: 46,
  },
  searchIcon: {
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    color: T.cream,
    fontSize: T.font.body,
  },
  categoriesScroll: {
    maxHeight: 44,
    marginBottom: T.sp.md,
  },
  categoriesContent: {
    paddingHorizontal: T.sp.lg,
  },
  categoryChip: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 14,
    height: 36,
    borderRadius: T.r.full,
    backgroundColor: T.elevated,
    borderWidth: 1,
    borderColor: T.border,
  },
  categoryChipActive: {
    backgroundColor: T.gold,
    borderColor: T.gold,
  },
  categoryChipMargin: {
    marginLeft: T.sp.sm,
  },
  categoryIcon: {
    fontSize: 13,
  },
  categoryName: {
    color: T.silver,
    fontSize: 13,
    fontWeight: '700',
    marginLeft: 5,
  },
  categoryNameActive: {
    color: T.obsidian,
  },
  menuList: {
    paddingHorizontal: T.sp.lg,
    paddingBottom: 20,
  },
  menuItem: {
    marginBottom: T.sp.sm,
    flexDirection: 'row',
    overflow: 'hidden',
  },
  menuItemImage: {
    width: 80,
    height: 80,
  },
  menuItemContent: {
    flex: 1,
    padding: T.sp.md,
  },
  menuItemHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    marginBottom: 2,
  },
  menuItemName: {
    color: T.cream,
    fontSize: 15,
    fontWeight: '800',
    flex: 1,
    marginRight: 8,
  },
  menuItemPrice: {
    color: T.gold,
    fontSize: 15,
    fontWeight: '900',
  },
  menuItemSubtitle: {
    color: T.ghost,
    fontSize: 12,
    marginBottom: 5,
  },
  menuItemMeta: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  menuItemDot: {
    color: T.muted,
    fontSize: 12,
    marginHorizontal: 6,
  },
  menuItemTime: {
    color: T.ghost,
    fontSize: 12,
  },
  menuItemTag: {
    marginLeft: 6,
  },
  
  // Detail Sheet Styles
  detailSheet: {
    paddingHorizontal: T.sp.lg,
    paddingBottom: T.sp.md,
  },
  detailImage: {
    width: '100%',
    height: 200,
    borderTopLeftRadius: T.r.lg,
    borderTopRightRadius: T.r.lg,
  },
  detailGradient: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 100,
  },
  detailContent: {
    marginTop: -40,
    paddingTop: T.sp.lg,
  },
  detailTags: {
    flexDirection: 'row',
    marginBottom: T.sp.md,
    flexWrap: 'wrap',
  },
  detailTag: {
    marginRight: 6,
    marginBottom: 4,
  },
  detailDescription: {
    color: T.silver,
    fontSize: T.font.body,
    lineHeight: 24,
    marginBottom: T.sp.lg,
  },
  detailStats: {
    flexDirection: 'row',
    backgroundColor: T.surface,
    borderRadius: T.r.md,
    borderWidth: 1,
    borderColor: T.border,
    marginBottom: T.sp.lg,
    overflow: 'hidden',
  },
  detailStat: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: T.sp.md,
    borderRightWidth: 1,
    borderRightColor: T.border,
  },
  detailStatLabel: {
    color: T.cream,
    fontSize: 13,
    fontWeight: '700',
    marginTop: 4,
  },
  allergens: {
    color: T.ghost,
    fontSize: 12,
    marginBottom: T.sp.lg,
  },
  detailActions: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: T.sp.lg,
  },
  quantitySelector: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: T.elevated,
    borderRadius: T.r.md,
    borderWidth: 1,
    borderColor: T.border,
    paddingHorizontal: T.sp.md,
    height: 54,
    marginRight: T.sp.md,
  },
  quantityDisplay: {
    color: T.cream,
    fontSize: T.font.title,
    fontWeight: '800',
    marginHorizontal: 16,
    minWidth: 24,
    textAlign: 'center',
  },
  addButton: {
    flex: 1,
  },
  
  // Reservation Styles
  reservationContent: {
    paddingHorizontal: T.sp.lg,
    paddingBottom: 40,
  },
  reservationCard: {
    padding: T.sp.lg,
    marginBottom: T.sp.lg,
  },
  cardTitle: {
    color: T.gold,
    fontSize: T.font.micro,
    fontWeight: '700',
    letterSpacing: 2,
    textTransform: 'uppercase',
    marginBottom: T.sp.md,
  },
  timeSection: {
    marginBottom: T.sp.md,
  },
  timeGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  timeSlot: {
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: T.r.full,
    borderWidth: 1,
    borderColor: T.border,
    backgroundColor: T.surface,
    marginRight: T.sp.sm,
    marginBottom: T.sp.sm,
  },
  timeSlotActive: {
    borderColor: T.gold,
    backgroundColor: T.gold + '18',
  },
  timeSlotText: {
    color: T.ghost,
    fontSize: 13,
    fontWeight: '600',
  },
  timeSlotTextActive: {
    color: T.gold,
  },
  sizeSection: {
    marginBottom: T.sp.md,
  },
  sizeControls: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  sizeDisplay: {
    alignItems: 'center',
    marginHorizontal: T.sp.lg,
  },
  sizeNumber: {
    color: T.cream,
    fontSize: 32,
    fontWeight: '900',
  },
  sizeLabel: {
    color: T.ghost,
    fontSize: 12,
  },
  occasionSection: {
    marginBottom: T.sp.lg,
  },
  occasionChip: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: T.r.full,
    borderWidth: 1,
    borderColor: T.border,
    backgroundColor: T.surface,
  },
  occasionChipActive: {
    borderColor: T.gold,
    backgroundColor: T.gold + '18',
  },
  occasionChipMargin: {
    marginLeft: T.sp.sm,
  },
  occasionText: {
    color: T.ghost,
    fontSize: 13,
  },
  occasionTextActive: {
    color: T.gold,
  },
  reserveButton: {
    marginTop: T.sp.sm,
  },
  reservationItem: {
    marginBottom: T.sp.sm,
  },
  reservationItemContent: {
    padding: T.sp.md,
  },
  reservationHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 5,
  },
  reservationName: {
    color: T.cream,
    fontSize: 15,
    fontWeight: '700',
  },
  reservationStatus: {
    paddingHorizontal: 10,
    paddingVertical: 3,
    borderRadius: T.r.full,
  },
  reservationStatusText: {
    fontSize: 11,
    fontWeight: '700',
    textTransform: 'uppercase',
  },
  reservationDetails: {
    color: T.ghost,
    fontSize: 13,
  },
  reservationOccasion: {
    color: T.gold,
    fontSize: 12,
    marginTop: 3,
  },
  reservationId: {
    color: T.muted,
    fontSize: 11,
    marginTop: 4,
  },
  
  // Cart Styles
  cartContent: {
    paddingHorizontal: T.sp.lg,
    paddingBottom: 40,
  },
  cartItems: {
    marginBottom: T.sp.lg,
  },
  cartItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: T.sp.md,
  },
  cartItemImage: {
    width: 48,
    height: 48,
    borderRadius: T.r.md,
    marginRight: T.sp.md,
  },
  cartItemInfo: {
    flex: 1,
  },
  cartItemName: {
    color: T.cream,
    fontSize: 14,
    fontWeight: '700',
  },
  cartItemPrice: {
    color: T.ghost,
    fontSize: 12,
  },
  cartItemControls: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: T.sp.sm,
  },
  cartItemQty: {
    color: T.cream,
    fontSize: 15,
    fontWeight: '800',
    marginHorizontal: 8,
    minWidth: 18,
    textAlign: 'center',
  },
  cartItemTotal: {
    alignItems: 'flex-end',
  },
  cartItemTotalPrice: {
    color: T.gold,
    fontSize: 14,
    fontWeight: '800',
    marginBottom: 4,
  },
  summaryCard: {
    padding: T.sp.lg,
    marginBottom: T.sp.lg,
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  summaryLabel: {
    color: T.ghost,
    fontSize: T.font.body,
  },
  summaryValue: {
    color: T.silver,
    fontSize: T.font.body,
  },
  summaryDivider: {
    marginVertical: T.sp.sm,
  },
  totalRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  totalLabel: {
    color: T.cream,
    fontSize: T.font.title,
    fontWeight: '800',
  },
  totalValue: {
    color: T.gold,
    fontSize: T.font.title,
    fontWeight: '900',
  },
  loyaltyEarn: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: T.sp.sm,
  },
  loyaltyEarnText: {
    color: T.gold,
    fontSize: 12,
    marginLeft: 5,
  },
  pickupCard: {
    marginBottom: T.sp.lg,
  },
  pickupGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    padding: T.sp.lg,
  },
  pickupSlot: {
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: T.r.full,
    borderWidth: 1,
    borderColor: T.border,
    backgroundColor: T.surface,
    marginRight: T.sp.sm,
    marginBottom: T.sp.sm,
  },
  pickupSlotActive: {
    borderColor: T.gold,
    backgroundColor: T.gold + '18',
  },
  pickupSlotText: {
    color: T.ghost,
    fontSize: 13,
    fontWeight: '600',
  },
  pickupSlotTextActive: {
    color: T.gold,
  },
  placeOrderButton: {
    marginBottom: T.sp.md,
  },
  emptyCart: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyCartEmoji: {
    fontSize: 64,
    marginBottom: T.sp.lg,
  },
  emptyCartTitle: {
    color: T.cream,
    fontSize: T.font.title,
    fontWeight: '700',
    marginBottom: 8,
  },
  emptyCartSubtitle: {
    color: T.ghost,
    fontSize: T.font.body,
  },
  
  // Profile Styles
  profileContent: {
    paddingHorizontal: T.sp.lg,
    paddingBottom: 40,
  },
  profileHeader: {
    alignItems: 'center',
    marginBottom: T.sp.xl,
  },
  profileAvatar: {
    width: 88,
    height: 88,
    borderRadius: 44,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: T.sp.md,
    borderWidth: 2,
    borderColor: T.gold + '55',
  },
  avatarEmoji: {
    fontSize: 38,
  },
  profileName: {
    color: T.cream,
    fontSize: T.font.heading,
    fontWeight: '800',
  },
  profileMember: {
    color: T.ghost,
    fontSize: T.font.caption,
    marginTop: 4,
  },
  loyaltyCard: {
    borderRadius: T.r.lg,
    padding: T.sp.lg,
    borderWidth: 1,
    borderColor: T.gold + '44',
    marginBottom: T.sp.lg,
  },
  loyaltyHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: T.sp.md,
  },
  loyaltyLabel: {
    color: T.goldDim,
    fontSize: T.font.micro,
    fontWeight: '700',
    letterSpacing: 2,
    textTransform: 'uppercase',
  },
  loyaltyTier: {
    fontSize: T.font.heading,
    fontWeight: '900',
  },
  loyaltyPoints: {
    color: T.goldLight,
    fontSize: 28,
    fontWeight: '900',
    marginBottom: 4,
  },
  loyaltyPointsUnit: {
    fontSize: 14,
    fontWeight: '600',
    color: T.goldDim,
  },
  progressBar: {
    height: 6,
    backgroundColor: T.gold + '22',
    borderRadius: 3,
    marginTop: T.sp.sm,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: T.gold,
    borderRadius: 3,
  },
  progressText: {
    color: T.goldDim,
    fontSize: 11,
    marginTop: 6,
  },
  statsGrid: {
    flexDirection: 'row',
    marginBottom: T.sp.lg,
  },
  statBox: {
    flex: 1,
    alignItems: 'center',
    padding: T.sp.md,
  },
  statBoxMargin: {
    marginLeft: T.sp.sm,
  },
  statBoxNumber: {
    color: T.cream,
    fontSize: T.font.heading,
    fontWeight: '900',
  },
  statBoxLabel: {
    color: T.ghost,
    fontSize: 11,
    marginTop: 2,
  },
  settingsCard: {
    marginBottom: T.sp.lg,
  },
  settingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: T.sp.md,
    paddingVertical: 14,
  },
  settingIcon: {
    marginRight: T.sp.md,
  },
  settingLabel: {
    flex: 1,
    color: T.cream,
    fontSize: T.font.body,
    fontWeight: '500',
  },
  settingDivider: {
    marginLeft: 52,
  },
  signOutButton: {
    marginBottom: T.sp.md,
  },
  
  // Manager Styles
  managerHeader: {
    paddingHorizontal: T.sp.lg,
    paddingTop: T.sp.lg,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: T.sp.lg,
  },
  managerGreeting: {
    color: T.ghost,
    fontSize: T.font.caption,
    letterSpacing: 1,
  },
  managerTitle: {
    color: T.cream,
    fontSize: T.font.heading,
    fontWeight: '800',
  },
  managerActions: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  liveIndicator: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    backgroundColor: T.success + '18',
    borderRadius: T.r.full,
    borderWidth: 1,
    borderColor: T.success + '44',
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 12,
  },
  liveDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: T.success,
    marginRight: 5,
  },
  liveText: {
    color: T.success,
    fontSize: 12,
    fontWeight: '700',
  },
  managerContent: {
    paddingHorizontal: T.sp.lg,
    paddingBottom: 40,
  },
  statCardEven: {
    marginLeft: T.sp.sm,
  },
  statCardInner: {
    padding: T.sp.md,
  },
  statIcon: {
    width: 40,
    height: 40,
    borderRadius: T.r.sm,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: T.sp.sm,
  },
  statCardValue: {
    color: T.cream,
    fontSize: T.font.heading,
    fontWeight: '900',
  },
  statCardLabel: {
    color: T.ghost,
    fontSize: 12,
    marginTop: 2,
  },
  liveOrder: {
    marginBottom: T.sp.sm,
  },
  liveOrderContent: {
    padding: T.sp.md,
  },
  liveOrderHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 4,
  },
  liveOrderId: {
    color: T.cream,
    fontSize: 14,
    fontWeight: '700',
  },
  liveOrderDetails: {
    color: T.ghost,
    fontSize: 12,
  },
  liveOrderTotal: {
    color: T.gold,
    fontSize: 13,
    fontWeight: '700',
    marginTop: 4,
  },
  
  // Orders Styles
  filterScroll: {
    maxHeight: 44,
    marginBottom: T.sp.sm,
  },
  filterContent: {
    paddingHorizontal: T.sp.lg,
  },
  filterChip: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: T.r.full,
    borderWidth: 1,
    borderColor: T.border,
    backgroundColor: T.elevated,
  },
  filterChipActive: {
    borderColor: T.success,
    backgroundColor: T.success + '18',
  },
  filterChipMargin: {
    marginLeft: T.sp.sm,
  },
  filterText: {
    color: T.ghost,
    fontSize: 12,
    fontWeight: '700',
    textTransform: 'capitalize',
  },
  filterTextActive: {
    color: T.success,
  },
  ordersList: {
    paddingHorizontal: T.sp.lg,
    paddingBottom: 20,
  },
  orderCard: {
    marginBottom: T.sp.sm,
  },
  orderCardContent: {
    padding: T.sp.md,
  },
  orderHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 8,
  },
  orderId: {
    color: T.cream,
    fontSize: 15,
    fontWeight: '800',
  },
  orderCustomer: {
    color: T.ghost,
    fontSize: 12,
    marginTop: 2,
  },
  orderMeta: {
    alignItems: 'flex-end',
  },
  orderTime: {
    color: T.ghost,
    fontSize: 11,
    marginTop: 4,
  },
  orderItems: {
    backgroundColor: T.surface,
    borderRadius: T.r.sm,
    padding: T.sp.sm,
    marginBottom: T.sp.sm,
  },
  orderItem: {
    color: T.silver,
    fontSize: 13,
    marginBottom: 2,
  },
  orderNotes: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    backgroundColor: T.warning + '11',
    borderRadius: T.r.sm,
    padding: T.sp.sm,
    marginBottom: T.sp.sm,
  },
  orderNotesText: {
    color: T.warning,
    fontSize: 12,
    flex: 1,
    marginLeft: 5,
  },
  orderFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  orderTotal: {
    color: T.gold,
    fontSize: 15,
    fontWeight: '900',
  },
  advanceButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: T.success,
    borderRadius: T.r.full,
  },
  advanceButtonText: {
    color: T.obsidian,
    fontSize: 12,
    fontWeight: '800',
  },
  
  // Manager Menu Styles
  managerMenuList: {
    paddingHorizontal: T.sp.lg,
    paddingBottom: 20,
  },
  managerMenuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: T.sp.md,
    marginBottom: T.sp.sm,
  },
  managerMenuImage: {
    width: 50,
    height: 50,
    borderRadius: T.r.md,
    marginRight: T.sp.md,
  },
  managerMenuInfo: {
    flex: 1,
  },
  managerMenuName: {
    color: T.cream,
    fontSize: 14,
    fontWeight: '700',
  },
  managerMenuCategory: {
    color: T.ghost,
    fontSize: 12,
    textTransform: 'capitalize',
    marginTop: 2,
  },
  managerMenuPrice: {
    color: T.gold,
    fontSize: 15,
    fontWeight: '800',
    marginRight: T.sp.md,
  },
  
  // Add Menu Sheet
  addMenuSheet: {
    paddingHorizontal: T.sp.lg,
    paddingBottom: T.sp.md,
  },
  emojiPicker: {
    marginBottom: T.sp.md,
  },
  emojiOption: {
    width: 44,
    height: 44,
    borderRadius: T.r.sm,
    backgroundColor: T.surface,
    borderWidth: 1,
    borderColor: T.border,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 8,
  },
  emojiOptionActive: {
    borderColor: T.gold,
    backgroundColor: T.gold + '22',
  },
  emojiText: {
    fontSize: 22,
  },
  categoryPicker: {
    marginBottom: T.sp.lg,
  },
  categoryGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  categoryOption: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: T.r.full,
    borderWidth: 1,
    borderColor: T.border,
    backgroundColor: T.surface,
    marginRight: T.sp.sm,
    marginBottom: T.sp.sm,
  },
  categoryOptionActive: {
    borderColor: T.gold,
    backgroundColor: T.gold + '18',
  },
  categoryOptionText: {
    color: T.ghost,
    fontSize: 13,
    textTransform: 'capitalize',
  },
  categoryOptionTextActive: {
    color: T.gold,
  },
  
  // Reservations Styles
  reservationsList: {
    paddingHorizontal: T.sp.lg,
    paddingBottom: 20,
  },
  reservationCardContent: {
    padding: T.sp.md,
  },
  reservationCardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 8,
  },
  reservationCardName: {
    color: T.cream,
    fontSize: 15,
    fontWeight: '800',
  },
  reservationCardId: {
    color: T.ghost,
    fontSize: 12,
    marginTop: 2,
  },
  reservationCardStatus: {
    paddingHorizontal: 10,
    paddingVertical: 3,
    borderRadius: T.r.full,
  },
  reservationCardStatusText: {
    fontSize: 11,
    fontWeight: '700',
    textTransform: 'uppercase',
  },
  reservationCardDetails: {
    flexDirection: 'row',
    marginBottom: 8,
  },
  reservationDetail: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: T.sp.md,
  },
  reservationDetailText: {
    color: T.silver,
    fontSize: 13,
    marginLeft: 4,
  },
  reservationPhone: {
    color: T.ghost,
    fontSize: 12,
    marginBottom: 12,
  },
  reservationActions: {
    flexDirection: 'row',
  },
  reservationAction: {
    flex: 1,
    paddingVertical: 10,
    borderRadius: T.r.md,
    alignItems: 'center',
  },
  confirmAction: {
    backgroundColor: T.success,
    marginRight: T.sp.sm,
  },
  confirmActionText: {
    color: T.obsidian,
    fontSize: 13,
    fontWeight: '800',
  },
  declineAction: {
    backgroundColor: T.danger + '22',
    borderWidth: 1,
    borderColor: T.danger + '55',
  },
  declineActionText: {
    color: T.danger,
    fontSize: 13,
    fontWeight: '800',
  },
  
  // Common Styles
  badge: {
    position: 'absolute',
    top: -4,
    right: -4,
    width: 16,
    height: 16,
    borderRadius: 8,
    backgroundColor: T.danger,
    alignItems: 'center',
    justifyContent: 'center',
  },
  badgeText: {
    color: '#fff',
    fontSize: 9,
    fontWeight: '800',
  },
  starsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  starsRating: {
    color: T.gold,
    fontSize: 12,
    fontWeight: '700',
    marginLeft: 3,
  },
  starsReviews: {
    color: T.ghost,
    fontSize: 11,
    marginLeft: 3,
  },
  loyaltyBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: T.gold + '18',
    borderWidth: 1,
    borderColor: T.gold + '44',
    borderRadius: T.r.full,
    paddingHorizontal: 12,
    paddingVertical: 6,
  },
  loyaltyText: {
    color: T.gold,
    fontSize: 13,
    fontWeight: '700',
    marginLeft: 5,
  },
  statusBadge: {
    paddingHorizontal: 10,
    paddingVertical: 3,
    borderRadius: T.r.full,
    borderWidth: 1,
  },
  statusText: {
    fontSize: 11,
    fontWeight: '700',
    textTransform: 'uppercase',
  },
  divider: {
    height: 1,
    backgroundColor: T.border,
  },
  sheet: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: T.surface,
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    borderWidth: 1,
    borderColor: T.border,
    borderBottomWidth: 0,
    maxHeight: SH * 0.9,
    paddingBottom: 34,
  },
  sheetOverlay: {
    backgroundColor: 'rgba(0,0,0,0.72)',
  },
  sheetOverlayTouch: {
    flex: 1,
  },
  sheetHandle: {
    alignItems: 'center',
    paddingTop: 12,
    paddingBottom: 16,
  },
  sheetHandleBar: {
    width: 40,
    height: 4,
    borderRadius: 2,
    backgroundColor: T.muted,
  },
  sheetTitle: {
    color: T.cream,
    fontSize: T.font.title,
    fontWeight: '700',
    marginTop: 14,
    letterSpacing: 0.3,
  },
  card: {
    backgroundColor: T.elevated,
    borderRadius: T.r.lg,
    borderWidth: 1,
    borderColor: T.border,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 4,
  },
  cardGlow: {
    shadowColor: T.gold,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.18,
    shadowRadius: 12,
    elevation: 8,
  },
  inputContainer: {
    marginBottom: T.sp.md,
  },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: T.surface,
    borderRadius: T.r.md,
    borderWidth: 1,
    borderColor: T.border,
    paddingHorizontal: T.sp.md,
    height: 52,
  },
  inputWrapperFocused: {
    borderColor: T.gold,
  },
  inputIcon: {
    marginRight: 10,
  },
  input: {
    flex: 1,
    color: T.cream,
    fontSize: T.font.body,
    fontWeight: '500',
  },
  inputMultiline: {
    height: 100,
    textAlignVertical: 'top',
    paddingTop: T.sp.sm,
  },
  goldButton: {
    height: 54,
    borderRadius: T.r.md,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
  },
  goldButtonOutline: {
    borderWidth: 1,
    borderColor: T.gold,
    backgroundColor: 'transparent',
  },
  buttonIcon: {
    marginRight: 6,
  },
  goldButtonText: {
    color: T.obsidian,
    fontSize: T.font.body,
    fontWeight: '800',
    letterSpacing: 0.5,
  },
  goldButtonTextOutline: {
    color: T.gold,
  },
  badgeContainer: {
    borderWidth: 1,
    borderRadius: T.r.full,
    paddingHorizontal: 8,
    paddingVertical: 3,
  },
  badgeLabel: {
    fontSize: T.font.micro,
    fontWeight: '700',
    letterSpacing: 0.5,
  },
  tabBar: {
    backgroundColor: T.surface,
    borderTopWidth: 1,
    borderTopColor: T.border,
    height: 80,
    paddingBottom: 20,
    paddingTop: 10,
  },
  tabBarLabel: {
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 0.5,
  },
  
  // Empty States
  emptyState: {
    alignItems: 'center',
    paddingVertical: 60,
  },
  emptyEmoji: {
    fontSize: 40,
    marginBottom: 12,
  },
  emptyText: {
    color: T.ghost,
    fontSize: T.font.body,
  },
  emptyTitle: {
    color: T.cream,
    fontSize: T.font.title,
    fontWeight: '700',
    marginBottom: 8,
  },
  emptySubtitle: {
    color: T.ghost,
    fontSize: T.font.body,
    textAlign: 'center',
  },
  
  // Spacers
  bottomSpacer: {
    height: 40,
  },
});